package com.ford.gpcse.service;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.List;

public interface ExportToExcelService {
    ByteArrayInputStream exportPartsBasedOnPartNumbers(List<String> partNumbers) throws IOException;
}
