package com.ford.gpcse.aop;

import com.ford.gpcse.common.Constants;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.stream.Collectors;

@Aspect
@Component
@Slf4j
public class LoggingAdvice {
    @Around("@annotation(com.ford.gpcse.aop.LoggingAspect)")
    public Object logging(ProceedingJoinPoint pjp) throws Throwable {
        MethodSignature methodSignature = (MethodSignature) pjp.getSignature();
        // Get intercepted method details
        String className = methodSignature.getDeclaringType().getSimpleName();
        String methodName = methodSignature.getName();
        String requestData = constructData(pjp);
        log.info("{} for {}.{}: Request Data={}", Constants.INITAL_REQUEST, className, methodName, requestData);
        Object proceed = pjp.proceed();
        log.info("{} for {}.{}: Response Data={}", Constants.FINAL_RESPONSE, className, methodName, proceed);
        return proceed;
    }

    // New method to log exceptions handled by GlobalExceptionHandler
    @AfterThrowing(pointcut = "execution(* com.ford.gpcse.exception.GlobalExceptionHandler.*(..))", throwing = "ex")
    public void logException(JoinPoint joinPoint, Exception ex) {
        String className = joinPoint.getSignature().getDeclaringTypeName();
        String methodName = joinPoint.getSignature().getName();
        String exceptionMessage = ex.getMessage();
        String exceptionDetails = Arrays.stream(joinPoint.getArgs())
                .map(String::valueOf)
                .collect(Collectors.joining(",", "[", "]"));
        log.error("Exception in {}.{}: Exception Message={}, Details={}", className, methodName, exceptionMessage, exceptionDetails);
    }

    private String constructData(JoinPoint jp) {
        return Arrays.stream(jp.getArgs())
                .map(String::valueOf)
                .collect(Collectors.joining(",", "[", "]"));
    }
}
