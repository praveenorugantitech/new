package com.ford.gpcse.exception;

public class UnableToInsertException extends RuntimeException {
    public UnableToInsertException(String message) {
        super(message);
    }
}