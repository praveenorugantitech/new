package com.ford.gpcse.util;

public class PartNumberUtility {

    // Private constructor to prevent instantiation
    private PartNumberUtility() {
        throw new UnsupportedOperationException("Utility class cannot be instantiated");
    }

    public static String incrementPartNumber(String pPn) {
        if (pPn.length() < 8) {
            return pPn;
        }

        String strLastChar = pPn.substring(pPn.length() - 1);
        String strNewPn;

        if (strLastChar.matches("[A-Z]")) {
            strNewPn = pPn.substring(0, pPn.length() - 1);

            switch (strLastChar) {
                case "H":
                    strLastChar = "I"; // Skip I
                    break;
                case "N":
                    strLastChar = "O"; // Skip O
                    break;
                case "P":
                    strLastChar = "Q"; // Skip Q
                    break;
                case "V":
                    strLastChar = "W"; // Skip W
                    break;
                default:
                    break;
            }
            return strNewPn + (char) (strLastChar.charAt(0) + 1);
        } else if (strLastChar.matches("\\d")) {
            // 10 - 99
            if (pPn.length() > 1 && pPn.substring(pPn.length() - 2).matches("\\d{2}")) {
                strNewPn = pPn.substring(0, pPn.length() - 2);
                return strNewPn + (Integer.parseInt(pPn.substring(pPn.length() - 2)) + 1);
            } else { // 0 - 9
                strNewPn = pPn.substring(0, pPn.length() - 1);
                return strNewPn + (Integer.parseInt(strLastChar) + 1);
            }
        } else {
            return pPn;
        }
    }


}
