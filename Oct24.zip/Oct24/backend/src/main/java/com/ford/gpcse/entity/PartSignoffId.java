package com.ford.gpcse.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Embeddable
@AllArgsConstructor
@NoArgsConstructor
@Data
@SuperBuilder
public class PartSignoffId {

    @Column(name = "PCMR20_SIGNOFF_TYP_C", length = 5)
    private String signoffTypC;

    @Column(name = "PCMR01_PART_R", length = 24)
    private String partR;
}
