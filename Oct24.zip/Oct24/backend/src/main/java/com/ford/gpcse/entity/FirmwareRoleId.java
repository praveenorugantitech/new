package com.ford.gpcse.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@AllArgsConstructor
@NoArgsConstructor
@Data
@SuperBuilder
@Embeddable
public class FirmwareRoleId {

    @Column(name = "PCMR03_FIRMWARE_K", nullable = false)
    private Long firmwareK;

    @Column(name = "PCM002_ROLE_K", nullable = false)
    private Long roleK;
}
