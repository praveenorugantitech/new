package com.ford.gpcse.bo;

import com.ford.gpcse.dto.UserRoleDto;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
@SuperBuilder
public class FirmwareDetailsResponse {
    private String firmwareType;
    private String description;
    private String independentVerifier;
    private List<UserRoleDto> owner;
}
