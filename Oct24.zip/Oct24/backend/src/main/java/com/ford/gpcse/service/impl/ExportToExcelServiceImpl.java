package com.ford.gpcse.service.impl;

import com.ford.gpcse.repository.FirmwareRepository;
import com.ford.gpcse.repository.PartFirmwareRepository;
import com.ford.gpcse.repository.PartRepository;
import com.ford.gpcse.service.ExportToExcelService;
import lombok.RequiredArgsConstructor;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class ExportToExcelServiceImpl implements ExportToExcelService {

    private final PartRepository partRepository;
    private final PartFirmwareRepository partFirmwareRepository;
    private final FirmwareRepository firmwareRepository;

    private static final String[] HEADERS = {
            "Part Number", "Firmware Program", "MY", "Program", "Platform",
            "Engine", "Transmission", "Lineage", "Release Type", "Release Usage",
            "Calib. No.", "Cal Variant", "Cal R Level", "Catch Word", "Release Eng.",
            "Hardware PN", "Core Hardware PN", "Core Hardware Owner", "Main Micro Type",
            "Supplier", "HCR Number", "Software PN", "Calibration PN", "Main Strategy",
            "Chip ID", "Build Level", "Release Priority", "Release Priority Details",
            "Concern", "WERS Notice", "WERS Description", "Backwards Compatibility",
            "Replaced P/N", "IPF Module P/N", "Service Module PN",
            "Reason for not Backwards Compatible", "Superseded",
            "Application Peer Reviewer", "Hardware Peer Reviewer",
            "Project Control Engineer", "Calibrator",
            "Assembly Peer Reviewer", "Label Type", "IVS Program",
            "Date Created", "Cal Date Planned", "Cal Date Actual",
            "Date Locked", "Release Status", "IVS Service Action"
    };

    @Override
    public ByteArrayInputStream exportPartsBasedOnPartNumbers(List<String> partNumbers) throws IOException {
        try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            List<Object[]> partResults = null;
            List<Object[]> firmwareResults = null;
            if (!partNumbers.isEmpty()) {
                partResults = partRepository.findAllPartsByIds(partNumbers);
                firmwareResults = partFirmwareRepository.findAllFirmwareByParts(partNumbers);
            }

            // Check for nulls and initialize empty lists if needed
            if (partResults == null) {
                partResults = List.of();
            }
            if (firmwareResults == null) {
                firmwareResults = List.of();
            }

            Map<String, String> firmwareMap = populateFirwareMap(firmwareResults);

            Sheet verticalSheet = workbook.createSheet("ExportFirmwareVertical");

            filltheDatainVertialSheet(partNumbers, verticalSheet, partResults, firmwareMap);

            Sheet horizontalSheet = workbook.createSheet("ExportFirmwareHorizontal");
            filltheDatainHorizontalSheet(partNumbers, horizontalSheet, partResults, firmwareMap);

            workbook.write(out);
            return new ByteArrayInputStream(out.toByteArray());
        }
    }

    private void filltheDatainHorizontalSheet(List<String> partNumbers, Sheet horizontalSheet, List<Object[]> partResults, Map<String, String> firmwareMap) {
        // Create headers in the horizontal sheet
        int totalNumberOfHeaderRows = createHorizontalHeaderColumn(horizontalSheet, partNumbers);

        // Start from the second column for part data (the first column is reserved for headers)
        int partColumnIndex = 1; // First column for part data

        for (Object[] partResult : partResults) {
            if (partResult != null) {
                // Fill in each row for this specific part
                // We will create or get the appropriate row based on the index
                for (int rowIndex = 0; rowIndex < totalNumberOfHeaderRows; rowIndex++) {
                    Row row = horizontalSheet.getRow(rowIndex);

                    if (row == null) {
                        row = horizontalSheet.createRow(rowIndex); // Create row if it doesn't exist
                        // Optionally set row height or auto-size column width
                        row.setHeightInPoints(26); // Example row height
                    }
                    // Optionally set row height or auto-size column width
                    row.setHeightInPoints(26); // Example row height


                    // Fill data in the current column for the current row
                    switch (rowIndex) {
                        case 0:
                            row.createCell(partColumnIndex).setCellValue(partResult[0] != null ? partResult[0].toString() : ""); // PCMR01_PART_R
                            break;
                        case 1:
                            row.createCell(partColumnIndex).setCellValue(getSafeValue(partResult[45]));  // PCMS01_MDL_YR_R
                            break;
                        case 2:
                            row.createCell(partColumnIndex).setCellValue(getSafeValue(partResult[46]));  // PCMS01_PGM_N
                            break;
                        case 3:
                            row.createCell(partColumnIndex).setCellValue(getSafeValue(partResult[47]));  // PCMS01_PLAT_N
                            break;
                        case 4:
                            row.createCell(partColumnIndex).setCellValue(getSafeValue(partResult[48]));  // PCMS01_ENG_N
                            break;
                        case 5:
                            row.createCell(partColumnIndex).setCellValue(getSafeValue(partResult[49]));  // PCMS01_TRANS_N
                            break;
                        case 6:
                            row.createCell(partColumnIndex).setCellValue(getSafeValue(partResult[1]));   // PCMR01_PART_NUM_X
                            break;
                        case 7:
                            row.createCell(partColumnIndex).setCellValue(getSafeValue(partResult[21])); // PCMR15_REL_TYP_X
                            break;
                        case 8:
                            row.createCell(partColumnIndex).setCellValue(getSafeValue(partResult[16])); // PCMR24_REL_USG_X
                            break;
                        case 9:
                            row.createCell(partColumnIndex).setCellValue(getSafeValue(partResult[3]));  // PCMR01_CALIB_R
                            break;
                        case 10:
                            row.createCell(partColumnIndex).setCellValue(getSafeValue(partResult[4]));  // Cal Variant
                            break;
                        case 11:
                            row.createCell(partColumnIndex).setCellValue(getSafeValue(partResult[5]));  // Cal R Level
                            break;
                        case 12:
                            row.createCell(partColumnIndex).setCellValue(getSafeValue(partResult[2]));  // PCMR01_CATCHWORD_C
                            break;
                        case 13:
                            row.createCell(partColumnIndex).setCellValue(getSafeValue(partResult[9]));  // PCMR01_ENGINEER_CDSID_C
                            break;
                        case 14:
                            row.createCell(partColumnIndex).setCellValue(getSafeValue(partResult[10])); // PCMR01_HARDWARE_PART_R
                            break;
                        case 15:
                            row.createCell(partColumnIndex).setCellValue(getSafeValue(partResult[43])); // PCMR01_CORE_HARDWARE_PART_R
                            break;
                        case 16:
                            row.createCell(partColumnIndex).setCellValue(getSafeValue(partResult[44])); // PCMR01_CORE_HARDWARE_CDSID_C
                            break;
                        case 17:
                            row.createCell(partColumnIndex).setCellValue(getSafeValue(partResult[14])); // PCMR19_MICRO_TYP_X
                            break;
                        case 18:
                            row.createCell(partColumnIndex).setCellValue(getSafeValue(partResult[20])); // PCMR17_SUPL_X
                            break;
                        case 19:
                            row.createCell(partColumnIndex).setCellValue(getSafeValue(partResult[15])); // PCMR01_HCR_R
                            break;
                        case 20:
                            row.createCell(partColumnIndex).setCellValue(getSafeValue(partResult[13])); // PCMR01_STRAT_CALIB_PART_R
                            break;
                        case 21:
                            row.createCell(partColumnIndex).setCellValue(getSafeValue(partResult[29])); // PCMR01_STRAT_PART_R
                            break;
                        case 22:
                            row.createCell(partColumnIndex).setCellValue(getSafeValue(partResult[6]));   // PCMR01_STRAT_REL_C
                            break;
                        case 23:
                            row.createCell(partColumnIndex).setCellValue(getSafeValue(partResult[11])); // PCMR01_CHIP_D
                            break;
                        case 24:
                            row.createCell(partColumnIndex).setCellValue(getSafeValue(partResult[32])); // PCMR01_BLD_LVL_C
                            break;
                        case 25:
                            row.createCell(partColumnIndex).setCellValue(getSafeValue(partResult[33])); // PCMR01_PRTY_C
                            break;
                        case 26:
                            row.createCell(partColumnIndex).setCellValue(getSafeValue(partResult[34])); // PCMR01_PRTY_DTL_X
                            break;
                        case 27:
                            row.createCell(partColumnIndex).setCellValue(getSafeValue(partResult[8]));   // PCMR01_CONCERN_C
                            break;
                        case 28:
                            row.createCell(partColumnIndex).setCellValue(partResult[12] != null ? formatNotice(partResult[12].toString()) : ""); // PCMR01_WERS_NTC_R
                            break;
                        case 29:
                            row.createCell(partColumnIndex).setCellValue(getSafeValue(partResult[28])); // PCMR01_CMT_X
                            break;
                        case 30:
                            row.createCell(partColumnIndex).setCellValue(getSafeValue(partResult[22])); // PCMR26_BACKWARD_COMPAT_X
                            break;
                        case 31:
                            row.createCell(partColumnIndex).setCellValue(getSafeValue(partResult[23])); // PCMR01_REPLACED_PART_R
                            break;
                        case 32:
                            row.createCell(partColumnIndex).setCellValue(getSafeValue(partResult[24])); // PCMR01_IPF_PART_R
                            break;
                        case 33:
                            row.createCell(partColumnIndex).setCellValue(getSafeValue(partResult[17])); // PCMR01_SVC_MODULE_PART_R
                            break;
                        case 34:
                            row.createCell(partColumnIndex).setCellValue(getSafeValue(partResult[25])); // PCMR01_BACKWARD_COMPAT_GRP_C
                            break;
                        case 35:
                            row.createCell(partColumnIndex).setCellValue(getSafeValue(partResult[37])); // Superseded
                            break;
                        case 36:
                            row.createCell(partColumnIndex).setCellValue(getSafeValue(partResult[38])); // Application Peer Reviewer
                            break;
                        case 37:
                            row.createCell(partColumnIndex).setCellValue(getSafeValue(partResult[36])); // Hardware Peer Reviewer
                            break;
                        case 38:
                            row.createCell(partColumnIndex).setCellValue(getSafeValue(partResult[35])); // PCMR01_PROJ_CTL_ENG_CDSID_C
                            break;
                        case 39:
                            row.createCell(partColumnIndex).setCellValue(getSafeValue(partResult[26])); // PCMR01_PWRTRN_CALIB_CDSID_C
                            break;
                        case 40:
                            row.createCell(partColumnIndex).setCellValue(getSafeValue(partResult[30])); // Assembly Peer Reviewer
                            break;
                        case 41:
                            row.createCell(partColumnIndex).setCellValue(getSafeValue(partResult[19])); // Label Type
                            break;
                        case 42:
                            row.createCell(partColumnIndex).setCellValue(getSafeValue(partResult[31])); // PCMS01_IVS_PGM_D
                            break;
                        case 43:
                            row.createCell(partColumnIndex).setCellValue(getSafeValue(partResult[51])); // PCMR01_CONCERN_Y
                            break;
                        case 44:
                            row.createCell(partColumnIndex).setCellValue(getSafeValue(partResult[18])); // PCMR01_CAL_REL_PLAN_Y
                            break;
                        case 45:
                            row.createCell(partColumnIndex).setCellValue(getSafeValue(partResult[52])); // PCMR01_CAL_REL_ACT_Y
                            break;
                        case 46:
                            row.createCell(partColumnIndex).setCellValue(getSafeValue(partResult[7]));   // PCMR01_PART_TYP_Y
                            break;
                        case 47:
                            row.createCell(partColumnIndex).setCellValue(getSafeValue(partResult[39])); // Admin Tool
                            break;
                        case 48:
                            row.createCell(partColumnIndex).setCellValue(getSafeValue(partResult[40])); // Gated Exit
                            break;
                        case 49:
                            row.createCell(partColumnIndex).setCellValue(getSafeValue(partResult[52])); // PCMR01_ECO_D
                            break;
                        case 50:
                            row.createCell(partColumnIndex).setCellValue(getSafeValue(partResult[53])); // Sub assembly part
                            break;
                        default:
                            break;
                    }
                    // Logic for firmware data columns
                    String partNumber = partResult[0] != null ? partResult[0].toString() : "";
                    String firmwareData = firmwareMap.getOrDefault(partNumber, ""); // Default to empty if not found

                    if (firmwareData != null && !firmwareData.isEmpty() && !firmwareData.isBlank()) {
                        String[] firmwareDataArray = firmwareData.split(",");
                        int totalNumberofPendingColumnValues = totalNumberOfHeaderRows - 50;
                        if (firmwareDataArray.length == totalNumberofPendingColumnValues) {
                            for (int i = 0; i < totalNumberofPendingColumnValues; i++) {
                                row.createCell(50 + i).setCellValue(firmwareDataArray[i]);
                            }
                        }
                    }

                }


            }
            // Set the width for the part column
            horizontalSheet.setColumnWidth(partColumnIndex, 256 * 15);
            // Move to the next part (next column)
            partColumnIndex++;
        }


    }


    // Create headers in the first column
    private int createHorizontalHeaderColumn(Sheet sheet, List<String> partNumbers) {
        Workbook workbook = sheet.getWorkbook();
        CellStyle headerStyle = workbook.createCellStyle();

        // Set font to bold
        Font font = workbook.createFont();
        font.setBold(true);
        headerStyle.setFont(font);

        // Static headers first (in the first column, each header in a new row)
        int rowIndex = 0; // Row index will increase for each header, but column is always 0 (first column)
        for (String header : HEADERS) {
            Row row = sheet.createRow(rowIndex); // Create new row for each header
            Cell cell = row.createCell(0); // Create cell in the first column (column 0)
            cell.setCellValue(header);
            cell.setCellStyle(headerStyle); // Apply bold style to header

            // Optionally set row height or auto-size column width
            row.setHeightInPoints(20); // Example row height
            sheet.autoSizeColumn(0); // Adjust width of the first column (optional)

            rowIndex++; // Move to the next row
        }

        // Fetch firmware column headers based on part numbers
        List<Object[]> firmwareHeaders = firmwareRepository.findFirmwareColumnHeaders(partNumbers);

        // Add dynamic firmware headers (also in the first column but in subsequent rows)
        for (Object[] row : firmwareHeaders) {
            String firmwareName = (String) row[1]; // PCM03_FIRMWARE_N

            Row rowObj = sheet.createRow(rowIndex); // Create new row for firmware name
            Cell cell = rowObj.createCell(0); // Create cell in the first column (column 0)
            cell.setCellValue(firmwareName);
            cell.setCellStyle(headerStyle); // Apply bold style

            // Optionally set row height or auto-size column width
            rowObj.setHeightInPoints(20); // Example row height
            sheet.autoSizeColumn(0); // Adjust width of the first column (optional)

            rowIndex++; // Move to the next row
        }

        // Return total number of rows (headers)
        return rowIndex; // This is the total number of headers created
    }


    private void filltheDatainVertialSheet(List<String> partNumbers, Sheet verticalSheet, List<Object[]> partResults, Map<String, String> firmwareMap) {
        int totalNumberOfHeaderColumns = createVerticalHeaderRow(verticalSheet, partNumbers);

        // Write the results to the sheet
        int rowNum = 1;
        for (Object[] partResult : partResults) {
            if (partResult != null) {
                Row row = verticalSheet.createRow(rowNum++); // Create a new row
                createVerticalDataRow(partResult, row, firmwareMap, totalNumberOfHeaderColumns);

            }
        }
    }

    private int createVerticalHeaderRow(Sheet sheet, List<String> partNumbers) {
        Row headerRow = sheet.createRow(0);
        headerRow.setHeightInPoints(20);

        // Create a font for the header and set it to bold
        Workbook workbook = sheet.getWorkbook();
        CellStyle headerStyle = workbook.createCellStyle();
        Font font = workbook.createFont();
        font.setBold(true);
        headerStyle.setFont(font);

        // Create static headers first
        int columnIndex = 0;
        for (String header : HEADERS) {
            Cell cell = headerRow.createCell(columnIndex);
            cell.setCellValue(header);
            cell.setCellStyle(headerStyle); // Apply the bold style

            // Set the column width based on the header length
            int columnWidth = header.length() * 512;
            sheet.setColumnWidth(columnIndex, columnWidth);
            columnIndex++;
        }

        // Fetch firmware column headers based on part numbers
        List<Object[]> firmwareHeaders = firmwareRepository.findFirmwareColumnHeaders(partNumbers);

        // Create dynamic headers based on fetched Firmware_N values
        for (Object[] row : firmwareHeaders) {
            String firmwareName = (String) row[1]; // PCM03_FIRMWARE_N

            Cell cell = headerRow.createCell(columnIndex);
            cell.setCellValue(firmwareName);
            cell.setCellStyle(headerStyle); // Apply the bold style

            // Set the column width based on the header length
            int columnWidth = firmwareName.length() * 512;
            sheet.setColumnWidth(columnIndex, columnWidth);
            columnIndex++;
        }

        // Return the total number of columns
        return columnIndex; // This will be the total number of headers
    }


    private void createVerticalDataRow(Object[] partResult, Row row, Map<String, String> firmwareMap, int totalNumberOfHeaderColumns) {
        row.createCell(0).setCellValue(partResult[0] != null ? partResult[0].toString() : ""); // PCMR01_PART_R
        String firmwareProgram =
                getSafeValue(partResult[45]) + "," +  // PCMS01_MDL_YR_R
                        getSafeValue(partResult[46]) + "," + // PCMS01_PGM_N
                        getSafeValue(partResult[47]) + "," + // PCMS01_PLAT_N
                        getSafeValue(partResult[48]) + "," + // PCMS01_ENG_N
                        getSafeValue(partResult[49]);        // PCMS01_TRANS_N

        row.createCell(1).setCellValue(firmwareProgram); // Firmware Program
        row.createCell(2).setCellValue(getSafeValue(partResult[45])); // PCMS01_MDL_YR_R
        row.createCell(3).setCellValue(getSafeValue(partResult[46])); // PCMS01_PGM_N
        row.createCell(4).setCellValue(getSafeValue(partResult[47])); // PCMS01_PLAT_N
        row.createCell(5).setCellValue(getSafeValue(partResult[48])); // PCMS01_ENG_N
        row.createCell(6).setCellValue(getSafeValue(partResult[49])); // PCMS01_TRANS_N
        row.createCell(7).setCellValue(getSafeValue(partResult[1]));   // PCMR01_PART_NUM_X
        row.createCell(8).setCellValue(getSafeValue(partResult[21])); // PCMR15_REL_TYP_X
        row.createCell(9).setCellValue(getSafeValue(partResult[16])); // PCMR24_REL_USG_X
        row.createCell(10).setCellValue(getSafeValue(partResult[3]));  // PCMR01_CALIB_R
        row.createCell(11).setCellValue(getSafeValue(partResult[4]));  // Cal Variant
        row.createCell(12).setCellValue(getSafeValue(partResult[5]));  // Cal R Level
        row.createCell(13).setCellValue(getSafeValue(partResult[2]));  // PCMR01_CATCHWORD_C
        row.createCell(14).setCellValue(getSafeValue(partResult[9]));  // PCMR01_ENGINEER_CDSID_C
        row.createCell(15).setCellValue(getSafeValue(partResult[10])); // PCMR01_HARDWARE_PART_R
        row.createCell(16).setCellValue(getSafeValue(partResult[43])); // PCMR01_CORE_HARDWARE_PART_R
        row.createCell(17).setCellValue(getSafeValue(partResult[44])); // PCMR01_CORE_HARDWARE_CDSID_C
        row.createCell(18).setCellValue(getSafeValue(partResult[14])); // PCMR19_MICRO_TYP_X
        row.createCell(19).setCellValue(getSafeValue(partResult[20])); // PCMR17_SUPL_X
        row.createCell(20).setCellValue(getSafeValue(partResult[15])); // PCMR01_HCR_R
        row.createCell(21).setCellValue(getSafeValue(partResult[13])); // PCMR01_STRAT_CALIB_PART_R
        row.createCell(22).setCellValue(getSafeValue(partResult[29])); // PCMR01_STRAT_PART_R
        row.createCell(23).setCellValue(getSafeValue(partResult[6]));   // PCMR01_STRAT_REL_C
        row.createCell(24).setCellValue(getSafeValue(partResult[11])); // PCMR01_CHIP_D
        row.createCell(25).setCellValue(getSafeValue(partResult[32])); // PCMR01_BLD_LVL_C
        row.createCell(26).setCellValue(getSafeValue(partResult[33])); // PCMR01_PRTY_C
        row.createCell(27).setCellValue(getSafeValue(partResult[34])); // PCMR01_PRTY_DTL_X
        row.createCell(28).setCellValue(getSafeValue(partResult[8]));   // PCMR01_CONCERN_C
        row.createCell(29).setCellValue(partResult[12] != null ? formatNotice(partResult[12].toString()) : ""); // PCMR01_WERS_NTC_R
        row.createCell(30).setCellValue(getSafeValue(partResult[28])); // PCMR01_CMT_X
        row.createCell(31).setCellValue(getSafeValue(partResult[22])); // PCMR26_BACKWARD_COMPAT_X
        row.createCell(32).setCellValue(getSafeValue(partResult[23])); // PCMR01_REPLACED_PART_R
        row.createCell(33).setCellValue(getSafeValue(partResult[24])); // PCMR01_IPF_PART_R
        row.createCell(34).setCellValue(getSafeValue(partResult[17])); // PCMR01_SVC_MODULE_PART_R
        row.createCell(35).setCellValue(getSafeValue(partResult[25])); // PCMR01_BACKWARD_COMPAT_GRP_C
        row.createCell(36).setCellValue(getSafeValue(partResult[37])); // Superseded
        row.createCell(37).setCellValue(getSafeValue(partResult[38])); // Application Peer Reviewer
        row.createCell(38).setCellValue(getSafeValue(partResult[36])); // Hardware Peer Reviewer
        row.createCell(39).setCellValue(getSafeValue(partResult[35])); // PCMR01_PROJ_CTL_ENG_CDSID_C
        row.createCell(40).setCellValue(getSafeValue(partResult[26])); // PCMR01_PWRTRN_CALIB_CDSID_C
        row.createCell(41).setCellValue(getSafeValue(partResult[30])); // Assembly Peer Reviewer
        row.createCell(42).setCellValue(getSafeValue(partResult[19])); // Label Type
        row.createCell(43).setCellValue(getSafeValue(partResult[31])); // PCMS01_IVS_PGM_D
        row.createCell(44).setCellValue(getSafeValue(partResult[50])); // PCMR01_CONCERN_Y
        row.createCell(45).setCellValue(getSafeValue(partResult[18])); // PCMR01_CAL_REL_PLAN_Y
        row.createCell(46).setCellValue(getSafeValue(partResult[51])); // PCMR01_CAL_REL_ACT_Y
        row.createCell(47).setCellValue(getSafeValue(partResult[7]));   // PCMR01_RELD_Y
        row.createCell(48).setCellValue(partResult[27] != null ? releaseStatusText(partResult[27].toString()) : ""); // PCMR01_STAT_C
        row.createCell(49).setCellValue("");   // PCMR04_IVS_SERVICE_ACTION_R column not found in WPCMR04_PGM_PART table

        createFirmwareVerticalCellData(partResult, firmwareMap, totalNumberOfHeaderColumns, row);
    }

    private static void createFirmwareVerticalCellData(Object[] partResult, Map<String, String> firmwareMap, int totalNumberOfHeaderColumns, Row row) {
        // logic for firmware data columns
        // Retrieve the concatenated firmware values for the current part number
        String partNumber = partResult[0] != null ? partResult[0].toString() : "";
        String firmwareData = firmwareMap.getOrDefault(partNumber, ""); // Default to empty if not found

        if (firmwareData != null && !firmwareData.isEmpty() && !firmwareData.isBlank()) {
            String[] firmwareDataArray = firmwareData.split(",");
            int totalNumberofPendingColumnValues = totalNumberOfHeaderColumns - 50;
            if (firmwareDataArray.length == totalNumberofPendingColumnValues) {
                for (int i = 0; i < totalNumberofPendingColumnValues; i++) {
                    row.createCell(50 + i).setCellValue(firmwareDataArray[i]);
                }
            }


        }
    }

    private static Map<String, String> populateFirwareMap(List<Object[]> firmwareResults) {
        // Use a map to associate part numbers with their firmware data
        Map<String, String> firmwareMap = new HashMap<>();

        // Populate the firmwareMap with concatenated firmware and file names
        for (Object[] firmwareResult : firmwareResults) {
            if (firmwareResult != null && firmwareResult.length >= 3) {
                String partNumber = firmwareResult[0] != null ? firmwareResult[0].toString() : "";
                String fileName = firmwareResult[2] != null ? firmwareResult[2].toString() : "";

                String currentValue = firmwareMap.getOrDefault(partNumber, "");
                if (!currentValue.isEmpty()) {
                    currentValue += ","; // Add a comma if there's already a value
                }
                currentValue += fileName; // Concatenate firmware and file name
                firmwareMap.put(partNumber, currentValue);
            }
        }
        return firmwareMap;
    }

    private static String releaseStatusText(String releaseStatusCode) {
        return switch (releaseStatusCode) {
            case "NewPnRequest" -> "New Part Number Request";
            case "PeadEdit", "PeadComplete" -> "Module Base Info Edit";
            case "FirmwareEdit" -> "Firmware Edit";
            case "SoftLock" -> "Soft Lock";
            case "HardLock" -> "Hard Lock";
            case "Complete" -> "Release Complete";
            default -> "";
        };
    }


    private static String formatNotice(String notice) {
        if (notice.length() == 16) {
            return String.format("%s %s %s %s",
                    notice.substring(0, 4),
                    notice.charAt(4),
                    notice.substring(5, 13),
                    notice.substring(13, 16));
        }

        return notice;
    }

    private static String getSafeValue(Object value) {
        return value != null ? value.toString() : "";
    }


}
