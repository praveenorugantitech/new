package com.ford.gpcse.controller;

import com.ford.gpcse.aop.LoggingAspect;
import com.ford.gpcse.aop.TrackExecutionTime;
import com.ford.gpcse.bo.ExportFirwareXmlRequest;
import com.ford.gpcse.service.ExportToExcelService;
import com.ford.gpcse.service.ExportToXmlService;
import com.ford.gpcse.util.DateFormatterUtility;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1_0/export")
@Tag(description = "Fetch Firmware Xml and Export Parts Based on Part Numbers to Excel", name = "Export Data")
public class ExportDataController {

    private final ExportToXmlService exportToXmlService;

    private final ExportToExcelService exportToExcelService;

    @TrackExecutionTime
    @LoggingAspect
    @PostMapping(value = "/parts")
    @Operation(
            summary = "Export Parts Based On Part Numbers",
            description = "Export Parts Based On Part Numbers"
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully Exported Parts to Excel")
    })
    public ResponseEntity<Resource> exportPartsBasedOnPartNumbers(@RequestBody List<String> partNumbers) {
        try {
            InputStream partsExcelReportStream = exportToExcelService.exportPartsBasedOnPartNumbers(partNumbers);
            HttpHeaders headers = new HttpHeaders();
            headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=FirmwareExport.xlsx");
            headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);

            return ResponseEntity.ok().headers(headers).body(new InputStreamResource(partsExcelReportStream));
        } catch (IOException e) {
            return ResponseEntity
                    .status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new InputStreamResource(new ByteArrayInputStream(("Error occurred: " + e.getMessage()).getBytes())));
        }
    }

    @TrackExecutionTime
    @LoggingAspect
    @PostMapping(value = "/firmware-xml")
    @Operation(
            summary = "Fetch Firmware xml",
            description = "Fetch Firmware xml"
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully Retrieved the Firmware Xml")
    })
    public ResponseEntity<Resource> fetchFirmareXml(@RequestBody ExportFirwareXmlRequest exportFirwareXmlRequest) {
        Resource resource = exportToXmlService.fetchFirmareXml(exportFirwareXmlRequest);
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION,
                        "attachment; filename=" +
                                (exportFirwareXmlRequest.getFileName() != null && !exportFirwareXmlRequest.getFileName().isEmpty()
                                        ? exportFirwareXmlRequest.getFileName()
                                        : DateFormatterUtility.dateTimeStringFormatFilename(LocalDateTime.now()) + ".xml")
                )
                .header(HttpHeaders.CONTENT_TYPE, "application/xml")
                .body(resource);
    }


}
