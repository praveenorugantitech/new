package com.ford.gpcse.dto;

import com.ford.gpcse.entity.RelUsg;
import com.ford.gpcse.entity.ReleaseType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PartFirwareDto {
    private String partR;
    private String partNumX;
    private String calibPartR;
    private String stratRelC;
    private String engineerCdsidC;
    private String hardwarePartR;
    private String microTypX;
    private String chipD;
    private String stratCalibPartR;
    private String catchWordC;
    private RelUsg releaseUsage;
    private ReleaseType releaseType;
    private String stratPartR;
    private String cmtX;
    private String coreHardwarePartR;
    private String concernC;

}
