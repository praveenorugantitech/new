package com.ford.gpcse.service.impl;

import com.ford.gpcse.bo.CreateSblRequest;
import com.ford.gpcse.bo.ReplaceSblRequest;
import com.ford.gpcse.dto.ReplaceSblPartDetailsDto;
import com.ford.gpcse.entity.*;
import com.ford.gpcse.exception.ResourceAlreadyExistException;
import com.ford.gpcse.exception.ResourceNotFoundException;
import com.ford.gpcse.exception.UnableToInsertException;
import com.ford.gpcse.exception.UnableToUpdateException;
import com.ford.gpcse.external.email.service.EmailService;
import com.ford.gpcse.repository.*;
import com.ford.gpcse.util.PartNumberUtility;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class SblServiceImplTest {

    @Mock
    private PartRepository partRepository;

    @Mock
    private EmailService emailService;

    @Mock
    private PartSignoffRepository partSignoffRepository;

    @Mock
    private RelUsgRepository relUsgRepository;

    @Mock
    private SupplierRepository supplierRepository;

    @Mock
    private ModuleTypeRepository moduleTypeRepository;

    @Mock
    private MicroTypeRepository microTypeRepository;

    @Mock
    private ReleaseTypeRepository releaseTypeRepository;

    @InjectMocks
    private SblServiceImpl sblService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void createSbl_success() {
        CreateSblRequest request = CreateSblRequest.builder()
                .supplierCode("SUPP1")
                .description("Sample description")
                .leadMyProgram("Lead My Program")
                .userId("User1")
                .moduleTypeCode("MOD1")
                .microTypeCode(1L)
                .build();

        Part savedPart = new Part();
        savedPart.setPartR("SBL-User1-20230930-SBL");
        when(partRepository.save(any(Part.class))).thenReturn(savedPart);
        when(partRepository.updatePartStatusAndCalib(anyString(), anyString())).thenReturn(1);
        when(partSignoffRepository.updateUserCdsidCForSignoffs(anyString(), anyString())).thenReturn(1);

        sblService.createSbl(request);

        verify(partRepository).save(any(Part.class));
        verify(emailService).sendMail(any());
    }

    @Test
    void createSbl_unableToInsert() {
        CreateSblRequest request = CreateSblRequest.builder()
                .supplierCode("SUPP1")
                .description("Sample description")
                .leadMyProgram("Lead My Program")
                .userId("User1")
                .moduleTypeCode("MOD1")
                .microTypeCode(1L)
                .build();

        when(partRepository.save(any(Part.class))).thenReturn(new Part());

        Exception exception = assertThrows(UnableToInsertException.class, () -> sblService.createSbl(request));
        assertTrue(exception.getMessage().contains("Internal Error 1699"));
    }

    @Test
    void createSbl_hardLockUpdateFailed() {
        CreateSblRequest request = CreateSblRequest.builder()
                .supplierCode("SUPP1")
                .description("Sample description")
                .leadMyProgram("Lead My Program")
                .userId("User1")
                .moduleTypeCode("MOD1")
                .microTypeCode(1L)
                .build();

        Part savedPart = new Part();
        savedPart.setPartR("SBL-User1-20230930-SBL");
        when(partRepository.save(any(Part.class))).thenReturn(savedPart);
        when(partRepository.updatePartStatusAndCalib(anyString(), anyString())).thenReturn(0);

        Exception exception = assertThrows(UnableToUpdateException.class, () -> sblService.createSbl(request));
        assertTrue(exception.getMessage().contains("Unable to update HardLock status for part"));
    }

    @Test
    void createSbl_signoffUpdateFailed() {
        CreateSblRequest request = CreateSblRequest.builder()
                .supplierCode("SUPP1")
                .description("Sample description")
                .leadMyProgram("Lead My Program")
                .userId("User1")
                .moduleTypeCode("MOD1")
                .microTypeCode(1L)
                .build();

        Part savedPart = new Part();
        savedPart.setPartR("SBL-User1-20230930-SBL");
        when(partRepository.save(any(Part.class))).thenReturn(savedPart);
        when(partRepository.updatePartStatusAndCalib(anyString(), anyString())).thenReturn(1);
        when(partSignoffRepository.updateUserCdsidCForSignoffs(anyString(), anyString())).thenReturn(0);

        Exception exception = assertThrows(UnableToUpdateException.class, () -> sblService.createSbl(request));
        assertTrue(exception.getMessage().contains("Unable to update signoff type for part"));
    }

    @Test
    void createSbl_nullUserId() {
        CreateSblRequest request = CreateSblRequest.builder()
                .supplierCode("SUPP1")
                .description("Sample description")
                .leadMyProgram("Lead My Program")
                .userId(null) // Null userId
                .moduleTypeCode("MOD1")
                .microTypeCode(1L)
                .build();

        Part savedPart = new Part();
        savedPart.setPartR("SBL-Ram-20230930-SBL");
        when(partRepository.save(any(Part.class))).thenReturn(savedPart);
        when(partRepository.updatePartStatusAndCalib(anyString(), anyString())).thenReturn(1);
        when(partSignoffRepository.updateUserCdsidCForSignoffs(anyString(), anyString())).thenReturn(1);

        sblService.createSbl(request);
        verify(partRepository).save(any(Part.class));
    }

    @Test
    void replaceSbl_success() {
        ReplaceSblRequest request = new ReplaceSblRequest("MOD1", "CURRENT_PART", "Sample description", "User1");
        ReplaceSblPartDetailsDto partDetails = new ReplaceSblPartDetailsDto();
        partDetails.setNewPartCheck(0L);
        partDetails.setModuleTypeCode("MOD1");
        partDetails.setMicroTypeCode(1L);
        partDetails.setSupplierCode("SUPP1");

        when(partRepository.fetchPartDetails(any(), any())).thenReturn(List.of(partDetails));
        when(partRepository.save(any(Part.class))).thenReturn(Part.builder().partR(PartNumberUtility.incrementPartNumber(request.getCurrentPartNumber())).build());
        when(relUsgRepository.findByRelUsgC("PROD")).thenReturn(RelUsg.builder().relUsgC("PROD").build());
        when(releaseTypeRepository.findByRelTypC("SBL")).thenReturn(ReleaseType.builder().relTypC("SBL").build());
        when(moduleTypeRepository.findByModuleTypC(partDetails.getModuleTypeCode())).thenReturn(ModuleType.builder().moduleTypC(partDetails.getModuleTypeCode()).build());
        when(microTypeRepository.findByMicroTypC(partDetails.getMicroTypeCode())).thenReturn(MicroType.builder().microTypC(partDetails.getMicroTypeCode()).build());
        when(supplierRepository.findBySuplC(partDetails.getSupplierCode())).thenReturn(Supplier.builder().suplC(partDetails.getSupplierCode()).build());


        sblService.replaceSbl(request);

        verify(partRepository).fetchPartDetails("CURRENT_PART", PartNumberUtility.incrementPartNumber(request.getCurrentPartNumber()));
        verify(partRepository, times(1)).save(any(Part.class));
        verify(emailService).sendMail(any());
    }

    @Test
    void replaceSbl_failure() {
        ReplaceSblRequest request = ReplaceSblRequest.builder().description("Sample description").moduleTypeCode("MOD1").currentPartNumber("CURRENT_PART").build();
        ReplaceSblPartDetailsDto partDetails = new ReplaceSblPartDetailsDto();
        partDetails.setNewPartCheck(0L);
        partDetails.setModuleTypeCode("MOD1");
        partDetails.setMicroTypeCode(1L);
        partDetails.setSupplierCode("SUPP1");

        when(partRepository.fetchPartDetails(any(), any())).thenReturn(List.of(partDetails));
        when(partRepository.save(any(Part.class))).thenReturn(Part.builder().partR(PartNumberUtility.incrementPartNumber(request.getCurrentPartNumber())).build());
        when(relUsgRepository.findByRelUsgC("PROD")).thenReturn(RelUsg.builder().relUsgC("PROD").build());
        when(releaseTypeRepository.findByRelTypC("SBL")).thenReturn(ReleaseType.builder().relTypC("SBL").build());
        when(moduleTypeRepository.findByModuleTypC(partDetails.getModuleTypeCode())).thenReturn(ModuleType.builder().moduleTypC(partDetails.getModuleTypeCode()).build());
        when(microTypeRepository.findByMicroTypC(partDetails.getMicroTypeCode())).thenReturn(MicroType.builder().microTypC(partDetails.getMicroTypeCode()).build());
        when(supplierRepository.findBySuplC(partDetails.getSupplierCode())).thenReturn(Supplier.builder().suplC(partDetails.getSupplierCode()).build());

        when(partRepository.fetchPartDetails(any(), any())).thenReturn(List.of(partDetails));
        when(partRepository.save(any(Part.class))).thenReturn(new Part());

        Exception exception = assertThrows(UnableToInsertException.class, () -> sblService.replaceSbl(request));
        assertTrue(exception.getMessage().contains("Internal Error 1699"));
    }


    @Test
    void replaceSbl_currentPartNumberNull() {
        ReplaceSblRequest request = new ReplaceSblRequest("MOD1", null, "Sample description", "User1");
        Exception exception = assertThrows(IllegalArgumentException.class, () -> sblService.replaceSbl(request));
        assertEquals("Current Part Number must not be null", exception.getMessage());
    }

    @Test
    void replaceSbl_partNotFound() {
        ReplaceSblRequest request = new ReplaceSblRequest("MOD1", "CURRENT_PART", "Sample description", "User1");
        when(partRepository.fetchPartDetails("CURRENT_PART", "NEW_PART")).thenReturn(Collections.emptyList());

        Exception exception = assertThrows(ResourceNotFoundException.class, () -> sblService.replaceSbl(request));
        assertEquals("No Records were found.", exception.getMessage());
    }

    @Test
    void replaceSbl_partAlreadyExists() {
        ReplaceSblRequest request = new ReplaceSblRequest("MOD1", "CURRENT_PART", "Sample description", "User1");
        ReplaceSblPartDetailsDto replaceSblPartDetailsDto = new ReplaceSblPartDetailsDto();
        replaceSblPartDetailsDto.setNewPartCheck(1L);
        List<ReplaceSblPartDetailsDto> replaceSblPartDetailsDtos = new ArrayList<>();
        replaceSblPartDetailsDtos.add(replaceSblPartDetailsDto);

        when(partRepository.fetchPartDetails(any(), any())).thenReturn(replaceSblPartDetailsDtos);

        Exception exception = assertThrows(ResourceAlreadyExistException.class, () -> sblService.replaceSbl(request));
        assertTrue(exception.getMessage().contains("already exists in the database"));
    }
}
