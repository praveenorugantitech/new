package com.ford.gpcse.external.vsem.service.impl;

import com.ford.gpcse.config.AppConfig;
import com.ford.gpcse.external.vsem.service.AuthService;
import com.ford.gpcse.model.TokenResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

@Service
@RequiredArgsConstructor
public class AuthServiceImpl implements AuthService {
    private final AppConfig appConfig;
    private final RestTemplate restTemplateWithProxy;

    @Override
    public TokenResponse fetchToken() {
        // Prepare request body as MultiValueMap for www-form-urlencoded
        MultiValueMap<String, String> requestBody = new LinkedMultiValueMap<>();
        requestBody.add("grant_type", "client_credentials");
        requestBody.add("client_id", appConfig.getClientid());
        requestBody.add("client_secret", appConfig.getClientsecret());
        requestBody.add("scope", appConfig.getResource());

        // Set headers
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

        // Create the HttpEntity with body and headers
        HttpEntity<MultiValueMap<String, String>> requestEntity = new HttpEntity<>(requestBody, headers);

        try {
            // Send POST request using RestTemplate
            ResponseEntity<TokenResponse> response = restTemplateWithProxy.exchange(
                    appConfig.getOauthurl(),
                    HttpMethod.POST,
                    requestEntity,
                    TokenResponse.class);

            // Return the body of the response
            return response.getBody();
        } catch (RestClientException e) {
            throw new RuntimeException("Error fetching token", e);
        }
    }
}