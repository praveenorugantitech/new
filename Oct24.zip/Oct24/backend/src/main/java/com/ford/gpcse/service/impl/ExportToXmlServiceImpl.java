package com.ford.gpcse.service.impl;

import com.ford.gpcse.bo.ExportFirwareXmlRequest;
import com.ford.gpcse.service.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;

@Service
@RequiredArgsConstructor
@Slf4j
public class ExportToXmlServiceImpl implements ExportToXmlService {

    private final FirmwareXmlExportV3Service firmwareXmlExportV3Service;
    private final FirmwareXmlExportV4Service firmwareXmlExportV4Service;
    private final FirmwareXmlExportV5Service firmwareXmlExportV5Service;
    private final FirmwareXmlExportV6Service firmwareXmlExportV6Service;
    private final FirmwareXmlExportV7Service firmwareXmlExportV7Service;
    private final FirmwareXmlExportV8Service firmwareXmlExportV8Service;
    private final FirmwareXmlExportV9Service firmwareXmlExportV9Service;
    private final FirmwareXmlExportV10Service firmwareXmlExportV10Service;


    @Override
    public Resource fetchFirmareXml(ExportFirwareXmlRequest exportFirwareXmlRequest) {

        // Validation
        if ((exportFirwareXmlRequest.getConcernNumber() == null || exportFirwareXmlRequest.getConcernNumber().isEmpty()) &&
                (exportFirwareXmlRequest.getPartNumbers() == null || exportFirwareXmlRequest.getPartNumbers().isEmpty()) && (exportFirwareXmlRequest.getWersNoticeNumber() == null || exportFirwareXmlRequest.getWersNoticeNumber().isEmpty())) {
            try {
                ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
                outputStream.write("<ROOT><ERROR>YOU MUST PROVIDE A WHERE CLAUSE.</ERROR></ROOT>".getBytes(StandardCharsets.UTF_8));
                return new ByteArrayResource(outputStream.toByteArray());
            } catch (Exception e) {
                log.error("Error occurred while generating Firmware Xml : {}", e.getMessage());
            }
        }

        String exportVersion = exportFirwareXmlRequest.getExportVersion();
        return switch (exportVersion != null ? exportVersion : "default") {
            case "Version 3" -> firmwareXmlExportV3Service.generateFirmwareV3Xml(exportFirwareXmlRequest);
            case "Version 4" -> firmwareXmlExportV4Service.generateFirmwareV4Xml(exportFirwareXmlRequest);
            case "Version 5" -> firmwareXmlExportV5Service.generateFirmwareV5Xml(exportFirwareXmlRequest);
            case "Version 6" -> firmwareXmlExportV6Service.generateFirmwareV6Xml(exportFirwareXmlRequest);
            case "Version 7" -> firmwareXmlExportV7Service.generateFirmwareV7Xml(exportFirwareXmlRequest);
            case "Version 8" -> firmwareXmlExportV8Service.generateFirmwareV8Xml(exportFirwareXmlRequest);
            case "Version 9" -> firmwareXmlExportV9Service.generateFirmwareV9Xml(exportFirwareXmlRequest);
            default -> firmwareXmlExportV10Service.generateFirmwareV10Xml(exportFirwareXmlRequest);
        };
    }
}
