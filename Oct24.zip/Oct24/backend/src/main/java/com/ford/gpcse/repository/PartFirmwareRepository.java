package com.ford.gpcse.repository;

import com.ford.gpcse.common.Constants;
import com.ford.gpcse.dto.LookupPartFirmwareDto;
import com.ford.gpcse.entity.PartFirmware;
import com.ford.gpcse.entity.PartFirmwareId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PartFirmwareRepository extends JpaRepository<PartFirmware, PartFirmwareId>, JpaSpecificationExecutor<PartFirmware> {

    @Query("SELECT COUNT(f) FROM PartFirmware f WHERE f.fileN = :fileN")
    Long countByfileN(@Param("fileN") String fileN);

    @Query(value = "SELECT COUNT(PCMR03_FIRMWARE_K) FROM dbo.WPCMR02_PART_FIRMWARE WHERE PCMR01_PART_R = :partR", nativeQuery = true)
    Long countByPartR(@Param("partR") String partR);

    @Query(value = "SELECT count(PCMR01_PART_R) FROM dbo.WPCMR21_SIGNOFF_PART tblA WHERE tblA.PCMR01_PART_R = :partR AND  tblA.PCMR20_SIGNOFF_TYP_C IN ('SUPPR', 'PEERR', 'PEERA', 'HWPER', 'IVSEM')  ", nativeQuery = true)
    Long countByPartRHasReviewSignOff(@Param("partR") String partR);

    @Query("SELECT  new com.ford.gpcse.dto.LookupPartFirmwareDto(f.firmwareN, pf.fileN, pf.aprvdByCdsidC, f.firmwareCatgN, pf.aprvdY) " +
            "FROM PartFirmware pf " +
            "INNER JOIN Firmware f ON pf.firmware.firmwareK = f.firmwareK " +
            "WHERE pf.part.partR = :partR " +
            "ORDER BY f.sortOrdR, f.firmwareCatgN, f.firmwareN")
    List<LookupPartFirmwareDto> fetchPartFirmwareByPartNumber(@Param(Constants.PART_R) String partR);

    @Query(value = "SELECT PCMR01_PART_R, PCMR03_FIRMWARE_K, PCMR02_FILE_N " +
            "FROM WPCMR02_PART_FIRMWARE " +
            "WHERE PCMR01_PART_R IN :partNumbers " +
            "ORDER BY PCMR01_PART_R", nativeQuery = true)
    List<Object[]> findAllFirmwareByParts(@Param("partNumbers") List<String> partNumbers);


}
