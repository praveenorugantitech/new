package com.ford.gpcse.controller;


import com.ford.gpcse.aop.LoggingAspect;
import com.ford.gpcse.aop.TrackExecutionTime;
import com.ford.gpcse.bo.SupplierEnrollmentRequest;
import com.ford.gpcse.service.EnrollmentService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
@RequestMapping("/enrollment")
@Tag(description = "Supplier Enrollment", name = "Enrollment Operations")
public class EnrollmentController {

    private final EnrollmentService enrollmentService;

    @TrackExecutionTime
    @LoggingAspect
    @PostMapping(value = "/supplier")
    @Operation(
            summary = "Supplier Enrollment",
            description = "Supplier Enrollment"
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully Sent Supplier Enrollment Email")
    })
    public ResponseEntity<String> supplierEnrollment(@RequestBody SupplierEnrollmentRequest supplierEnrollmentRequest) {
        return ResponseEntity.ok(enrollmentService.supplierEnrollment(supplierEnrollmentRequest));
    }
}
