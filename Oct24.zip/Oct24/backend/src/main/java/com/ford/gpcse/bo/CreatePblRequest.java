package com.ford.gpcse.bo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@AllArgsConstructor
@NoArgsConstructor
@Data
@SuperBuilder
public class CreatePblRequest {
    private String newPbl;
    private String moduleTypeCode;
    private String createUser;
    private String lastUpdateUser;
}
