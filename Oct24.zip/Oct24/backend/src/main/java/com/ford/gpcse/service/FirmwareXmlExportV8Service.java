package com.ford.gpcse.service;

import com.ford.gpcse.bo.ExportFirwareXmlRequest;
import org.springframework.core.io.Resource;

public interface FirmwareXmlExportV8Service {
    Resource generateFirmwareV8Xml(ExportFirwareXmlRequest exportFirwareXmlRequest);
}
