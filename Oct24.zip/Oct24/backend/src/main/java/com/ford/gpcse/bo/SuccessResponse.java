package com.ford.gpcse.bo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class SuccessResponse<T> {

    private String status = "success";
    private T data;
    private String message;

    public SuccessResponse(String message, T data) {
        this.message = message;
        this.data = data;
    }
}
