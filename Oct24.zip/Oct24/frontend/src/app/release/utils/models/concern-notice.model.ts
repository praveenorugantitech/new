export class FindFirmWare {
    wersConcern ?: string ="";
    wersNotice ?: string="";
}

