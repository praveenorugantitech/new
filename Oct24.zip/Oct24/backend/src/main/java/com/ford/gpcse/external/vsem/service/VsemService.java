package com.ford.gpcse.external.vsem.service;

import com.ford.gpcse.model.VsemServiceResponse;

public interface VsemService {

    VsemServiceResponse fetchPartFilenames(String partNumber);
}
