package com.ford.gpcse.repository;

import com.ford.gpcse.entity.MicroType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MicroTypeRepository extends JpaRepository<MicroType, Long> {

    @Query("SELECT m FROM MicroType m WHERE m.microTypStatC = 'Released' AND m.archF = 'N' " +
            "AND (m.moduleType.moduleTypC = :moduleTypeCode OR m.moduleType.moduleTypC IS NULL) " +
            "ORDER BY m.microTypX")
    List<MicroType> fetchReleasedMicroTypesByModuleType(@Param("moduleTypeCode") String moduleTypeCode);

    @Query("SELECT COUNT(m) FROM MicroType m WHERE m.microTypX = :mainMicroTypeName")
    int countByMicroTypeName(@Param("mainMicroTypeName") String mainMicroTypeName);

    @Query("SELECT COALESCE(MAX(m.microTypC), 10000) + 1 FROM MicroType m")
    Long fetchMicroId();

    MicroType findByMicroTypC(Long microTypeCode);


}
