import { Component, OnInit } from "@angular/core";
import { ReleaseService } from "../../../../utils/services/release.service";
import { HttpErrorResponse } from "@angular/common/http";
import { ErrorResponse } from "../../../../utils/models/error-response.model";
import { ReleaseUtils } from "../../../../utils/ReleaseUtils";
import { Router } from "@angular/router";
@Component({
  selector: "app-release-status",
  templateUrl: "./release-status.component.html",
})
export class ReleaseStatusComponent implements OnInit {
  releaseStatuses: any[] = [];
  concern: string = "";
  displayConcernDetails: boolean = false;
  firmwareRecords: any[] = [];

  constructor(private router: Router, private releaseService: ReleaseService) {}

  ngOnInit() {
    this.fetchReleaseStatuses();
  }

  fetchReleaseStatuses() {
    this.releaseService.getReleaseStatusDetails().subscribe((data) => {
      this.releaseStatuses = data;
    });
  }

  onSubmit() {
    this.displayConcernDetails = true;
  }

  cancelSubmit() {
    window.scrollTo({ top: 0, behavior: "smooth" });
    this.router.navigate(["/"]);
  }  
}
