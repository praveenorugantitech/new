export class CommonSblModel {
  moduleTypeCode: string = "";
  description: string = "";
  userId: string = "";
}

export class AddSblPostModel extends CommonSblModel {
  supplierCode: string = "";
  microTypeCode: number = 0;
  leadMyProgram: string = "";
}

export class ReplaceSblPutModel extends CommonSblModel {
  currentPartNumber: string = "";
}

export class SblModel {
  releaseType: string = "new_sbl";
  supplierCode: string = "";
  supplierName: string = "";
  moduleTypeCode: string = "";
  moduleTypeName: string = "";
  microTypeCode: number = 0;
  microTypeName: string = "";
  description: string = "";
  leadMyProgram: string = "";
  currentPartNumber: string = "";
}
