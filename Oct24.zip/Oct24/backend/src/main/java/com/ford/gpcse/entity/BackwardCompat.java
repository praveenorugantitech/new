package com.ford.gpcse.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Data
@SuperBuilder
@Table(name = "WPCMR26_BACKWARD_COMPAT")
public class BackwardCompat {

    @Id
    @Column(name = "PCMR26_BACKWARD_COMPAT_C", nullable = false)
    private String backwardCompatC;

    @Column(name = "PCMR26_BACKWARD_COMPAT_X")
    private String backwardCompatX;

    @Column(name = "PCMR26_ARCH_F", nullable = false)
    private String archF;

    @Column(name = "PCMR26_SORT_ORD_R")
    private Long sortOrdR;

    @Column(name = "PCMR26_CREATE_USER_C", nullable = false)
    private String createUserC;

    @Column(name = "PCMR26_CREATE_S", nullable = false, updatable = false)
    @CreationTimestamp
    private LocalDateTime createS;

    @Column(name = "PCMR26_LAST_UPDT_USER_C", nullable = false)
    private String lastUpdtUserC;

    @Column(name = "PCMR26_LAST_UPDT_S", nullable = false)
    @UpdateTimestamp
    private LocalDateTime lastUpdtS;
}
