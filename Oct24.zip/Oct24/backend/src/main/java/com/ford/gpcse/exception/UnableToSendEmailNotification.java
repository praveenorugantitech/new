package com.ford.gpcse.exception;

public class UnableToSendEmailNotification extends RuntimeException {
    public UnableToSendEmailNotification(String message) {
        super(message);
    }
}
