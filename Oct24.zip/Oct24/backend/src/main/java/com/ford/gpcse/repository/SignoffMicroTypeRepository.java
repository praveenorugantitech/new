package com.ford.gpcse.repository;

import com.ford.gpcse.entity.SignoffMicroType;
import com.ford.gpcse.entity.SignoffMicroTypeId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

public interface SignoffMicroTypeRepository extends JpaRepository<SignoffMicroType, SignoffMicroTypeId> {

    @Modifying
    @Transactional
    @Query("UPDATE SignoffMicroType s SET s.reqtY = CURRENT_TIMESTAMP " +
            "WHERE s.id.signoffTypC = :signoff " +
            "AND s.signoffS IS NULL " +
            "AND s.reqtY IS NULL " +
            "AND s.id.microTypC = :microId")
    void updateSignoff(@Param("signoff") String signoff, @Param("microId") Long microId);
}
