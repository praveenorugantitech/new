package com.ford.gpcse.repository;

import com.ford.gpcse.entity.Signoff;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface SignoffRepository extends JpaRepository<Signoff, String> {

    @Query(value = "SELECT tblB.PCMR20_SIGNOFF_TYP_X, tblA.PCMR20_SIGNOFF_TYP_C, " +
            "DATEDIFF(MINUTE, PCMR21_REQT_Y, GETDATE()) " +
            "FROM dbo.WPCMR21_SIGNOFF_PART tblA " +
            "INNER JOIN dbo.WPCMR20_SIGNOFF tblB ON tblA.PCMR20_SIGNOFF_TYP_C = tblB.PCMR20_SIGNOFF_TYP_C " +
            "WHERE tblA.PCMR01_PART_R = :partR " +
            "AND tblA.PCMR21_SIGNOFF_S IS NULL " +
            "AND tblA.PCMR21_REQT_Y IS NOT NULL " +
            "AND tblA.PCMR20_SIGNOFF_TYP_C in :signOffTypes" +
            "ORDER BY tblB.PCMR20_SIGNOFF_TYP_X", nativeQuery = true)
    List<Object[]> findSignoffDetails(@Param("partR") String partR, @Param("signOffTypes") List<String> signOffTypes);
}
