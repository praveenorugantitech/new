package com.ford.gpcse.controller;

import com.ford.gpcse.aop.LoggingAspect;
import com.ford.gpcse.aop.TrackExecutionTime;
import com.ford.gpcse.bo.*;
import com.ford.gpcse.dto.ProgramDescriptionDto;
import com.ford.gpcse.service.LookupDataService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1_0/lookup")
@Tag(description = "Fetch All Active Micro Names, Fetch Released Micro Types Based on Module Type, Fetch All Active Module Names, Fetch All Active Module Types, Fetch Distinct Programs, Fetch All Active Suppliers, Fetch All Release Requests, Fetch All Release Status Details, Fetch Module Base Information Based on user id, Fetch Parts By Firmware, Fetch Prism Input Data Based on Part Number, Fetch Firmware Details Based on Release Type, Fetch Active Release Types and Fetch All Programs Which Has Part Number.", name = "Lookup Data")
public class LookupDataController {

    private final LookupDataService lookupDataService;

    @GetMapping("/suppliers")
    @Operation(description = "Fetch All Active Suppliers", summary = "Fetch All Active Suppliers")
    @LoggingAspect
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully retrieved resource"),
            @ApiResponse(responseCode = "404", description = "Resource not found")
    })
    public List<SupplierView> fetchActiveSuppliers() {
        return lookupDataService.fetchActiveSuppliers();
    }

    @GetMapping("/module-types")
    @Operation(description = "Fetch All Active Module Types", summary = "Fetch All Active Module Types")
    @LoggingAspect
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully retrieved resource"),
            @ApiResponse(responseCode = "404", description = "Resource not found")
    })
    public List<ModuleTypeView> fetchActiveModuleTypes() {
        return lookupDataService.fetchActiveModuleTypes();
    }

    @GetMapping("/micro-types")
    @Operation(description = "Fetch Released Micro Types Based on Module Type", summary = "Fetch Released Micro Types Based on Module Type")
    @LoggingAspect
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully retrieved resource"),
            @ApiResponse(responseCode = "404", description = "Resource not found")
    })
    public List<MicroTypeView> fetchReleasedMicroTypesByModuleType(@RequestParam String moduleTypeCode) {
        return lookupDataService.fetchReleasedMicroTypesByModuleType(moduleTypeCode);
    }

    @GetMapping("/release-types/module-type/{moduleTypeCode}")
    @Operation(description = "Fetch All Release Types Based on Module Type", summary = "Fetch All Release Types Based on Module Type")
    @LoggingAspect
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully retrieved resource"),
            @ApiResponse(responseCode = "404", description = "Resource not found")
    })
    public List<String> fetchReleaseTypesByModuleType(@PathVariable String moduleTypeCode) {
        return lookupDataService.fetchReleaseTypesByModuleType(moduleTypeCode);
    }

    @GetMapping("/micro-names")
    @Operation(description = "Fetch All Active Micro Names", summary = "Fetch All Active Micro Names")
    @LoggingAspect
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully retrieved resource"),
            @ApiResponse(responseCode = "404", description = "Resource not found")
    })
    public List<String> fetchActiveMicroNames() {
        return lookupDataService.fetchActiveMicroNames();
    }

    @GetMapping("/module-names")
    @Operation(description = "Fetch All Active Module Names", summary = "Fetch All Active Module Names")
    @LoggingAspect
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully retrieved resource"),
            @ApiResponse(responseCode = "404", description = "Resource not found")
    })
    public List<String> fetchActiveModuleNames() {
        return lookupDataService.fetchActiveModuleNames();
    }

    @GetMapping("/programs")
    @Operation(description = "Fetch Distinct Programs", summary = "Fetch Distinct Programs")
    @LoggingAspect
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully retrieved resource"),
            @ApiResponse(responseCode = "404", description = "Resource not found")
    })
    public List<ProgramDescriptionDto> fetchDistinctPrograms() {
        return lookupDataService.fetchDistinctPrograms();
    }

    @GetMapping("/programs/with-part-number")
    @Operation(description = "Fetch All Programs Which Has Part Number", summary = "Fetch All Programs Which Has Part Number")
    @LoggingAspect
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully retrieved resource"),
            @ApiResponse(responseCode = "404", description = "Resource not found")
    })
    public List<String> fetchAllProgramsWhichHasPartNumber() {
        return lookupDataService.fetchAllProgramsWhichHasPartNumber();
    }

    @LoggingAspect
    @TrackExecutionTime
    @GetMapping("/release-request")
    @Operation(description = "Fetch All Release Requests", summary = "Fetch All Release Requests")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "Successfully retrieved resource"), @ApiResponse(responseCode = "404", description = "Resource not found")})
    public List<ReleaseRequest> fetchAllReleaseRequests() {
        return lookupDataService.fetchAllReleaseRequests();
    }


    @LoggingAspect
    @TrackExecutionTime
    @GetMapping("/release-status")
    @Operation(description = "Fetch All Release Status Details", summary = "Fetch All Release Status Details")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "Successfully retrieved resource"), @ApiResponse(responseCode = "404", description = "Resource not found")})
    public List<ReleaseStatus> fetchReleaseStatusDetails() {
        return lookupDataService.fetchReleaseStatusDetails();
    }

    @LoggingAspect
    @TrackExecutionTime
    @GetMapping("/release-types")
    @Operation(description = "Fetch Active Release Types", summary = "Fetch Active Release Types")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "Successfully retrieved resource"), @ApiResponse(responseCode = "404", description = "Resource not found")})
    public List<ReleaseTypeView> fetchActiveReleaseTypes() {
        return lookupDataService.fetchActiveReleaseTypes();
    }

    @LoggingAspect
    @TrackExecutionTime
    @GetMapping("/module-base-info/user-id/{userId}")
    @Operation(description = "Fetch Module Base Information Based on User Id", summary = "Fetch Module Base Information Based on User Id")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "Successfully retrieved resource"), @ApiResponse(responseCode = "404", description = "Resource not found")})
    public List<ModuleBaseInformation> fetchModuleBaseInformation(@PathVariable("userId") String userId) {
        return lookupDataService.fetchModuleBaseInformation(userId);
    }

    @TrackExecutionTime
    @LoggingAspect
    @PostMapping(value = "/parts-by-firmware")
    @Operation(
            summary = "Fetch Parts by Firmware",
            description = "Fetch parts by firmware based on the current and replace PBL"
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully retrieved resource"),
            @ApiResponse(responseCode = "404", description = "Resource not found")
    })
    public ResponseEntity<List<PartFirmwareResponse>> findPartsByFirmware(@RequestBody ReplacePblSearchRequest replacePblSearchRequest) {
        return ResponseEntity.ok(lookupDataService.findPartsByFirmware(replacePblSearchRequest));
    }

    @TrackExecutionTime
    @LoggingAspect
    @GetMapping(value = "/data-prism-input/part-number/{partNumber}")
    @Operation(
            summary = "Fetch Prism Input Data Based on Part Number",
            description = "Fetch Prism Input Data Based on Part Number"
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully retrieved resource"),
            @ApiResponse(responseCode = "404", description = "Resource not found")
    })
    public ResponseEntity<PrismDataInputResponse> fetchPrismInputDataBasedOnPartNumber(@PathVariable("partNumber") String partNumber) {
        return ResponseEntity.ok(lookupDataService.fetchPrismInputDataBasedOnPartNumber(partNumber));
    }


    @TrackExecutionTime
    @LoggingAspect
    @GetMapping(value = "/firmware/release-type/{releaseType}")
    @Operation(
            summary = "Fetch Firmware Details Based on Release Type",
            description = "Fetch Firmware Details Based on Release Type"
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully retrieved resource"),
            @ApiResponse(responseCode = "404", description = "Resource not found")
    })
    public ResponseEntity<List<FirmwareDetailsResponse>> fetchFirmwareDetailsBasedOnReleaseType(@PathVariable("releaseType") String releaseType) {
        return ResponseEntity.ok(lookupDataService.fetchFirmwareDetailsBasedOnReleaseType(releaseType));
    }


}