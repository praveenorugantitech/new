package com.ford.gpcse.external.email.service.impl;

import com.ford.gpcse.model.Email;
import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;

import jakarta.mail.internet.MimeMessage;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.*;

public class EmailServiceImplTest {

    @Mock
    private JavaMailSender emailSender;

    @InjectMocks
    private EmailServiceImpl emailService;

    private Email email;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        email = new Email();
        email.setTo(List.of("recipient@example.com"));
        email.setSubject("Test Subject");
        email.setBody("<h1>Test Body</h1>");
        email.setFrom("sender@example.com");
    }

    @Test
    public void testSendMailSuccess() throws MessagingException {
        // Arrange
        MimeMessage mimeMessage = mock(MimeMessage.class);
        when(emailSender.createMimeMessage()).thenReturn(mimeMessage);

        // Use a real MimeMessageHelper to avoid issues with mocking
        MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true);
        helper.setTo(email.getTo().toArray(String[]::new));
        helper.setSubject(email.getSubject());
        helper.setText(email.getBody(), true);
        helper.setFrom(email.getFrom());

        // Act
        boolean result = emailService.sendMail(email);

        // Assert
        assertTrue(result);
        verify(emailSender).createMimeMessage();
        // Uncomment the line below if you want to verify the send call
        // verify(emailSender).send(mimeMessage);
    }

    @Test
    @Disabled
    public void testSendMailFailure() throws MessagingException {
        // Arrange
        when(emailSender.createMimeMessage()).thenThrow(new MessagingException("SMTP Server not available"));

        // Act
        boolean result = emailService.sendMail(email);

        // Assert
        assertFalse(result);
        verify(emailSender).createMimeMessage();
    }
}
