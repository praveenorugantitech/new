import { Component } from '@angular/core';

@Component({
  selector: 'app-release',
  templateUrl: './release.component.html',
  styleUrl: './release.component.scss'
})
export class ReleaseComponent {

}
