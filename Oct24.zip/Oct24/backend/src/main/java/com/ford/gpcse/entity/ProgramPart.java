package com.ford.gpcse.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Data
@SuperBuilder
@Table(name = "WPCMR04_PGM_PART")
public class ProgramPart {

    @Id
    @Column(name = "PCMS01_PGM_K")
    private Long pgmK;

    @ManyToOne
    @JoinColumn(name = "PCMR01_PART_R", referencedColumnName = "PCMR01_PART_R")
    private Part part;


    @Column(name = "PCMR04_CREATE_USER_C", nullable = false)
    private String createUserC;

    @Column(name = "PCMR04_CREATE_S", nullable = false, updatable = false)
    @CreationTimestamp
    private LocalDateTime createS;

    @Column(name = "PCMR04_LAST_UPDT_USER_C", nullable = false)
    private String lastUpdtUserC;

    @Column(name = "PCMR04_LAST_UPDT_S", nullable = false)
    @UpdateTimestamp
    private LocalDateTime lastUpdtS;

    @Column(name = "PCMR04_VADR_ICE_PACK_UL_CMPL_F")
    private String vadrIcePackUlCmplF;

    @Column(name = "PCMR04_SW_PRTL_UPLOAD_CMPLT_F")
    private String swPrtlUploadCmpltF;

    @Column(name = "PCMR04_CRIS_UPLOAD_CMPLT_F")
    private String crisUploadCmpltF;

    @Column(name = "PCMR04_VADR_ICE_PACK_ARTFCT_D")
    private String vadrIcePackArtfctD;
}
