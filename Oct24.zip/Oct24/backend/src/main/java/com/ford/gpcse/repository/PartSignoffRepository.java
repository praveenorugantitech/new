package com.ford.gpcse.repository;

import com.ford.gpcse.common.Constants;
import com.ford.gpcse.entity.PartSignoff;
import com.ford.gpcse.entity.PartSignoffId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public interface PartSignoffRepository extends JpaRepository<PartSignoff, PartSignoffId> {

    @Modifying
    @Transactional
    @Query("UPDATE PartSignoff ps SET ps.userCdsidC = " +
            "(SELECT p.engineerCdsidC FROM ps.part p WHERE p.partR = :partR) " +
            "WHERE ps.signoff.signoffTypC = :signoffType " +
            "AND ps.signoffS IS NULL")
    int updateUserCdsidCForSignoffs(@Param("signoffType") String signoffType,
                                    @Param(Constants.PART_R) String partR);

    @Query("SELECT ps FROM PartSignoff ps WHERE ps.part.partR = :partR AND ps.signoff.signoffTypC=:signoffTypC")
    PartSignoff findByPartRAndSignOffTypC(@Param("partR") String partR, @Param("signoffTypC") String signoffTypC);

}
