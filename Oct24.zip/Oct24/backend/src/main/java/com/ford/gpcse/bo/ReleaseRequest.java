package com.ford.gpcse.bo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@AllArgsConstructor
@NoArgsConstructor
@Data
@SuperBuilder
public class ReleaseRequest {
    private Long requestId;
    private String module;
    private String rLevel;
    private String my;
    private String prog;
    private String engine;
    private String status;
    private String created;
    private String owner;
}
