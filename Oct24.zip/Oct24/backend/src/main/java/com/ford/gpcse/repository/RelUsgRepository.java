package com.ford.gpcse.repository;

import com.ford.gpcse.entity.RelUsg;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface RelUsgRepository extends JpaRepository<RelUsg, String> {

    RelUsg findByRelUsgC(String releaseUsageCode);
}
