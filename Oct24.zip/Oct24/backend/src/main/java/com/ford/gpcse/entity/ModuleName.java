package com.ford.gpcse.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Data
@SuperBuilder
@Table(name = "WPCMF40_MODULE_NM")
public class ModuleName {
    @Id
    @Column(name = "PCMF40_MODULE_N")
    private String moduleN;

    @Column(name = "PCMF40_SORT_ORD_R")
    private Long sortOrdR;

    @Column(name = "PCMF40_ACTV_F")
    private String actvF;

    @Column(name = "PCMR40_CREATE_USER_C", nullable = false)
    private String createUserC;

    @Column(name = "PCMR40_CREATE_S", nullable = false, updatable = false)
    @CreationTimestamp
    private LocalDateTime createS;

    @Column(name = "PCMR40_LAST_UPDT_USER_C", nullable = false)
    private String lastUpdtUserC;

    @Column(name = "PCMR40_LAST_UPDT_S", nullable = false)
    @UpdateTimestamp
    private LocalDateTime lastUpdtS;

    @Column(name = "PCMF40_MOD_CATLG_C")
    private String modCatlgC;

    @OneToOne
    @JoinColumn(name = "PCMR14_MODULE_TYP_C", referencedColumnName = "PCMR14_MODULE_TYP_C")
    private ModuleType moduleType;
}
