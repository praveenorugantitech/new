package com.ford.gpcse.exception;

public class MicroTypeAlreadyRequestedException extends RuntimeException {
    public MicroTypeAlreadyRequestedException(String mainMicroTypeName) {
        super(mainMicroTypeName + " has already been requested.");
    }
}