package com.ford.gpcse.repository;

import com.ford.gpcse.common.Constants;
import com.ford.gpcse.entity.Firmware;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface FirmwareRepository extends JpaRepository<Firmware, Long> {

    @Query("SELECT pf.fileN FROM PartFirmware pf " +
            "JOIN pf.firmware fw " +
            "WHERE fw.firmwareN LIKE :firmwareNameLike " +
            "AND pf.part.partR = :partR")
    String fetchFileN(@Param(Constants.PART_R) String partNumber, @Param("firmwareNameLike") String firmwareNameLike);


    @Query("SELECT f FROM Firmware f WHERE f.selGrpR > 0 " +
            "AND f.firmwareK IN (SELECT r.firmware.firmwareK FROM ReleaseTypeFirmware r WHERE r.releaseType.relTypC = :releaseType) " +
            "ORDER BY f.sortOrdR, f.firmwareN")
    List<Firmware> fetchFirmwaresByReleaseType(@Param("releaseType") String releaseType);

    @Query("SELECT f FROM Firmware f INNER JOIN ReleaseTypeFirmware rt ON f.firmwareK = rt.firmware.firmwareK " +
            "WHERE f.firmwareN LIKE %:firmwareType% AND rt.releaseType.relTypC IN (SELECT p.releaseType.relTypC FROM Part p WHERE p.moduleType.moduleTypC = :moduleTypeCode)")
    List<Firmware> fetchFirmwareByModuleTypeCode(@Param("moduleTypeCode") String moduleTypeCode, @Param("firmwareType") String firmwareType);

    @Query(value = "SELECT DISTINCT tblA.PCMR03_FIRMWARE_K, tblA.PCMR03_FIRMWARE_N, tblA.PCMR03_SORT_ORD_R " +
            "FROM WPCMR03_FIRMWARE tblA " +
            "INNER JOIN WPCMR02_PART_FIRMWARE tblB ON tblA.PCMR03_FIRMWARE_K = tblB.PCMR03_FIRMWARE_K " +
            "WHERE tblB.PCMR01_PART_R IN :partNumbers " +
            "AND tblB.PCMR02_APRVD_Y is not null " +
            "ORDER BY tblA.PCMR03_SORT_ORD_R, tblA.PCMR03_FIRMWARE_N",
            nativeQuery = true)
    List<Object[]> findFirmwareColumnHeaders(@Param("partNumbers") List<String> partNumbers);


    @Query(value = "SELECT tblFw.PCMR03_FIRMWARE_N, tblFw.PCMR03_FIRMWARE_K " +
            "FROM dbo.WPCMR02_PART_FIRMWARE tblFwJ " +
            "INNER JOIN dbo.WPCMR03_FIRMWARE tblFw ON tblFwJ.PCMR03_FIRMWARE_K = tblFw.PCMR03_FIRMWARE_K " +
            "WHERE tblFwJ.PCMR01_PART_R = :partR " +
            "AND tblFwJ.PCMR02_APRVD_Y IS NULL " +
            "ORDER BY tblFw.PCMR03_SORT_ORD_R, tblFw.PCMR03_FIRMWARE_CATG_N, tblFw.PCMR03_FIRMWARE_N",
            nativeQuery = true)
    List<Object[]> findFirmwareDetails(@Param("partR") String partR);
}
