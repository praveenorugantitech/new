package com.ford.gpcse.service.impl;

import com.ford.gpcse.aop.LoggingAspect;
import com.ford.gpcse.bo.NewMicroMicroTypeRequest;
import com.ford.gpcse.entity.*;
import com.ford.gpcse.exception.MicroTypeAlreadyRequestedException;
import com.ford.gpcse.exception.UnableToInsertException;
import com.ford.gpcse.external.email.service.EmailService;
import com.ford.gpcse.model.Email;
import com.ford.gpcse.repository.MicroTypeRepository;
import com.ford.gpcse.repository.SignoffMicroTypeRepository;
import com.ford.gpcse.service.NewMainMicroTypeService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
@Slf4j
public class NewMicroTypeServiceImpl implements NewMainMicroTypeService {

    private final MicroTypeRepository microTypeRepository;
    private final SignoffMicroTypeRepository signoffMicroTypeRepository;
    private final EmailService emailService;


    @Override
    @Transactional
    public void addNewMainMicroType(NewMicroMicroTypeRequest newMicroMicroTypeRequest) {

        ModuleType moduleType = ModuleType.builder().moduleTypC(newMicroMicroTypeRequest.getModuleTypeCode()).build();
        Supplier supplier = Supplier.builder().suplC(newMicroMicroTypeRequest.getSupplierCode()).build();
        // Check if the main micro type name exists
        int count = microTypeRepository.countByMicroTypeName(newMicroMicroTypeRequest.getMainMicroTypeName());

        if (count > 0) {
            throw new MicroTypeAlreadyRequestedException(newMicroMicroTypeRequest.getMainMicroTypeName());
        }

        Long microId = microTypeRepository.fetchMicroId();


        MicroType microType = MicroType.builder().microTypC(microId)
                .microTypX(newMicroMicroTypeRequest.getMainMicroTypeName())
                .microTypOwnrCdsidC(newMicroMicroTypeRequest.getCreateUser())
                .createUserC(Optional.ofNullable(newMicroMicroTypeRequest.getCreateUser()).orElse("Ram"))
                .lastUpdtUserC(Optional.ofNullable(newMicroMicroTypeRequest.getLastUpdateUser()).orElse("Ram"))
                .moduleType(moduleType)
                .supplier(supplier)
                .archF("N")
                .build();

        MicroType savedMicroType= microTypeRepository.save(microType);

        if(savedMicroType.getMicroTypC() == null){
            throw new UnableToInsertException("Unable to insert " + microId + ". Internal Error 1699.");
        }

        // sign off
        SignoffMicroType signoffMicroType = SignoffMicroType.builder()
                .id(SignoffMicroTypeId.builder().signoffTypC("MMSUP").microTypC(microId).build())
                .microType(microType)
                .createUserC(newMicroMicroTypeRequest.getCreateUser())
                .lastUpdtUserC(newMicroMicroTypeRequest.getLastUpdateUser())
                .build();

        signoffMicroTypeRepository.save(signoffMicroType);

        // send Email
        sendNewMainMicroTypeEmail(newMicroMicroTypeRequest, microId);

        // write off
        signoffMicroTypeRepository.updateSignoff("MMSUP", microId);
    }

    @LoggingAspect
    private void sendNewMainMicroTypeEmail(NewMicroMicroTypeRequest newMicroMicroTypeRequest, Long microId) {

        String url = "";
        String baseUrl = "";

        String subject = "Release action required (Main Micro Supplier Review)";

        String emailBody = "<body><p>" + newMicroMicroTypeRequest.getCreateUser() + " has requested a new "
                + newMicroMicroTypeRequest.getModuleTypeCode() + " Main Micro Type '"
                + newMicroMicroTypeRequest.getMainMicroTypeName() + "' for "
                + newMicroMicroTypeRequest.getSupplierName()
                + ". Please use the link provided to review this request.</p><p><a href=\""
                + baseUrl + url + "?MicroId=" + microId + "\">" + baseUrl + url + "?MicroId="
                + microId + "</a></p><p>&nbsp;</p></body>";

        Email email = Email.builder().subject(subject)
                .to(List.of())
                .from("")// pcserel@ford.com
                .body(emailBody).build();

        emailService.sendMail(email);

    }
}
