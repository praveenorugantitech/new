package com.ford.gpcse.service.impl;

import com.ford.gpcse.bo.MicroTypeView;
import com.ford.gpcse.bo.ModuleTypeView;
import com.ford.gpcse.bo.SupplierView;
import com.ford.gpcse.entity.MicroType;
import com.ford.gpcse.entity.ModuleType;
import com.ford.gpcse.entity.Supplier;
import com.ford.gpcse.exception.ResourceNotFoundException;
import com.ford.gpcse.repository.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

public class LookupDataServiceImplTest {

    @Mock
    private SupplierRepository supplierRepository;
    @Mock
    private ModuleTypeRepository moduleTypeRepository;
    @Mock
    private MicroTypeRepository microTypeRepository;
    @Mock
    private ModuleNameRepository moduleNameRepository;
    @Mock
    private ProcessorRepository processorRepository;
    @Mock
    private ProgramDescriptionRepository programDescriptionRepository;

    @InjectMocks
    private LookupDataServiceImpl lookupDataServiceImpl;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }


    @Test
    void fetchActiveSuppliers_WhenSuppliersExist_ShouldReturnSupplierViews() {

        Supplier supplier1 = new Supplier();
        supplier1.setSuplC("Bosch");
        supplier1.setSuplX("Bosch");

        Supplier supplier2 = new Supplier();
        supplier2.setSuplC("Delphi");
        supplier2.setSuplX("Delphi");


        when(supplierRepository.fetchActiveSuppliers()).thenReturn(Arrays.asList(supplier1, supplier2));

        List<SupplierView> result = lookupDataServiceImpl.fetchActiveSuppliers();

        assertNotNull(result);
        assertEquals(2, lookupDataServiceImpl.fetchActiveSuppliers().size());
        assertEquals("Bosch", result.get(0).getSupplierCode());
        assertEquals("Bosch", result.get(0).getSupplierName());
        assertEquals("Delphi", result.get(1).getSupplierCode());
        assertEquals("Delphi", result.get(1).getSupplierName());
    }

    @Test
    void fetchActiveSuppliers_WhenNoSuppliersExist_ShouldThrowResourceNotFoundException() {

        when(supplierRepository.fetchActiveSuppliers()).thenReturn(Collections.emptyList());

        Exception exception = assertThrows(ResourceNotFoundException.class, () -> {
            lookupDataServiceImpl.fetchActiveSuppliers();
        });

        assertEquals("No Suppliers where found", exception.getMessage());
    }

    @Test
    void fetchActiveModuleTypes_WhenModuleTypesExist_ShouldReturnModuleTypeViews() {

        ModuleType moduleType1 = new ModuleType();
        moduleType1.setModuleTypC("BCCMI");
        moduleType1.setModuleTypX("BCCMI");

        ModuleType moduleType2 = new ModuleType();
        moduleType2.setModuleTypC("AWDCH");
        moduleType2.setModuleTypX("AWDCH");

        when(moduleTypeRepository.fetchActiveModuleTypes()).thenReturn(Arrays.asList(moduleType1, moduleType2));


        List<ModuleTypeView> result = lookupDataServiceImpl.fetchActiveModuleTypes();


        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals("BCCMI", result.get(0).getModuleTypeCode());
        assertEquals("BCCMI", result.get(0).getModuleTypeName());
        assertEquals("AWDCH", result.get(1).getModuleTypeCode());
        assertEquals("AWDCH", result.get(1).getModuleTypeName());
    }

    @Test
    void fetchActiveModuleTypes_WhenNoModuleTypesExist_ShouldThrowResourceNotFoundException() {

        when(moduleTypeRepository.fetchActiveModuleTypes()).thenReturn(Collections.emptyList());

        Exception exception = assertThrows(ResourceNotFoundException.class, () -> {
            lookupDataServiceImpl.fetchActiveModuleTypes();
        });

        assertEquals("No Module Types where found", exception.getMessage());
    }

    @Test
    void fetchReleasedMicroTypesByModuleType_WhenMicroTypesExist_ShouldReturnMicroTypeViews() {

        String moduleTypeCode = "BCCMI";
        MicroType microType1 = new MicroType();
        microType1.setMicroTypC(1L);
        microType1.setMicroTypX("SPANISH OAK 1024");

        MicroType microType2 = new MicroType();
        microType2.setMicroTypC(2L);
        microType2.setMicroTypX("MPC-563 Green Oak");

        when(microTypeRepository.fetchReleasedMicroTypesByModuleType(moduleTypeCode))
                .thenReturn(Arrays.asList(microType1, microType2));


        List<MicroTypeView> result = lookupDataServiceImpl.fetchReleasedMicroTypesByModuleType(moduleTypeCode);


        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals(1, result.get(0).getMicroTypeCode());
        assertEquals("SPANISH OAK 1024", result.get(0).getMicroTypeName());
        assertEquals(2, result.get(1).getMicroTypeCode());
        assertEquals("MPC-563 Green Oak", result.get(1).getMicroTypeName());
    }

    @Test
    void fetchReleasedMicroTypesByModuleType_WhenNoMicroTypesExist_ShouldThrowResourceNotFoundException() {

        String moduleTypeCode = "BCCMI";
        when(microTypeRepository.fetchReleasedMicroTypesByModuleType(moduleTypeCode))
                .thenReturn(Collections.emptyList());


        Exception exception = assertThrows(ResourceNotFoundException.class, () -> {
            lookupDataServiceImpl.fetchReleasedMicroTypesByModuleType(moduleTypeCode);
        });

        assertEquals("No Micro Types where found for given module type", exception.getMessage());
    }

    @Test
    void fetchActiveModuleNames_WhenModulesExist_ShouldReturnModuleNames() {

        List<String> expectedModuleNames = Arrays.asList("ModuleName1", "ModuleName2");
        when(moduleNameRepository.fetchActiveModuleNames()).thenReturn(expectedModuleNames);


        List<String> result = lookupDataServiceImpl.fetchActiveModuleNames();

        // Assert
        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals(expectedModuleNames, result);
    }

    @Test
    void fetchActiveModuleNames_WhenNoModulesExist_ShouldThrowResourceNotFoundException() {
        // Arrange
        when(moduleNameRepository.fetchActiveModuleNames()).thenReturn(Collections.emptyList());

        // Act & Assert
        ResourceNotFoundException exception = assertThrows(ResourceNotFoundException.class, () -> {
            lookupDataServiceImpl.fetchActiveModuleNames();
        });

        assertEquals("No Module Names where found", exception.getMessage());
    }

    @Test
    void fetchActiveMicroNames_WhenMicrosExist_ShouldReturnMicroNames() {

        List<String> expectedMicroNames = Arrays.asList("MicroName1", "MicroName2");
        when(processorRepository.fetchActiveMicroNames()).thenReturn(expectedMicroNames);

        List<String> result = lookupDataServiceImpl.fetchActiveMicroNames();

        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals(expectedMicroNames, result);
    }

    @Test
    void fetchActiveMicroNames_WhenNoMicrosExist_ShouldThrowResourceNotFoundException() {
        when(processorRepository.fetchActiveMicroNames()).thenReturn(Collections.emptyList());

        ResourceNotFoundException exception = assertThrows(ResourceNotFoundException.class, () -> {
            lookupDataServiceImpl.fetchActiveMicroNames();
        });

        assertEquals("No Micro Names where found", exception.getMessage());
    }

}
