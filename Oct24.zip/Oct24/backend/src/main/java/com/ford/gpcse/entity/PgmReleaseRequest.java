package com.ford.gpcse.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Data
@SuperBuilder
@Table(name = "WPCMR49_PGM_RELEASE_REQUEST")
public class PgmReleaseRequest {
    @Id
    @Column(name = "PCMS01_PGM_K")
    private Long pgmK;

    @NotNull
    @ManyToOne
    @JoinColumn(name = "PCMR48_REL_REQ_K", referencedColumnName = "PCMR48_REL_REQ_K", insertable = false, updatable = false)
    private ReleaseRequest releaseRequest;

    @ManyToOne
    @JoinColumn(name = "PCMS01_PGM_K", referencedColumnName = "PCMS01_PGM_K", insertable = false, updatable = false)
    private ProgramDescription programDescription;

    @Column(name = "PCMR49_CREATE_USER_C", nullable = false)
    private String createUserC;

    @Column(name = "PCMR49_CREATE_S", nullable = false, updatable = false)
    @CreationTimestamp
    private LocalDateTime createS;

    @Column(name = "PCMR49_LAST_UPDT_USER_C", nullable = false)
    private String lastUpdtUserC;

    @Column(name = "PCMR49_LAST_UPDT_S", nullable = false)
    @UpdateTimestamp
    private LocalDateTime lastUpdtS;


}
