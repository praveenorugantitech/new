package com.ford.gpcse.external.vsem.service.impl;

import com.ford.gpcse.config.AppConfig;
import com.ford.gpcse.external.vsem.service.AuthService;
import com.ford.gpcse.external.vsem.service.VsemService;
import com.ford.gpcse.model.VsemServiceResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

@Service
@RequiredArgsConstructor
public class VsemServiceImpl implements VsemService {
    private final AuthService authService;
    private final AppConfig appConfig;
    private final RestTemplate restTemplate;

    @Override
    public VsemServiceResponse fetchPartFilenames(String partNumber) {
        // Get access token
        String accessToken = authService.fetchToken().getAccessToken();

        // Prepare headers
        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", "Bearer " + accessToken);
        headers.set("partNumber", partNumber);

        // Create HttpEntity with headers
        HttpEntity<Void> requestEntity = new HttpEntity<>(headers);

        try {
            // Send GET request using RestTemplate
            ResponseEntity<VsemServiceResponse> response = restTemplate.exchange(
                    appConfig.getVsemurl(),
                    HttpMethod.GET,
                    requestEntity,
                    VsemServiceResponse.class);

            // Return the body of the response
            return response.getBody();
        } catch (RestClientException e) {
            throw new RuntimeException("Error fetching part filenames", e);
        }
    }
}
