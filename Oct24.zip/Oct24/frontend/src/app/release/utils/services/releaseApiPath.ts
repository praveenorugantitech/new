import { API_BASE_URL } from "../../../utils/shared-constants.model";

const API_V: string = "api/v1_0";
const COMMON_API_PATH: string = `${API_BASE_URL}/${API_V}`;

const API_PATH = Object.freeze({
  /********************************** LOOKUP API PATH *******************************************/
  SUPPLIER_API_PATH: `${COMMON_API_PATH}/lookup/suppliers`,
  MICROTYPES_API_PATH: `${COMMON_API_PATH}/lookup/micro-types`,
  MODULETYPES_API_PATH: `${COMMON_API_PATH}/lookup/module-types`,
  FETCH_PARTS_BY_FIRMWARE_API_PATH: `${COMMON_API_PATH}/lookup/parts-by-firmware`,
  MODULENAMES_API_PATH: `${COMMON_API_PATH}/lookup/module-names`,
  MICRONAMES_API_PATH: `${COMMON_API_PATH}/lookup/micro-names`,
  FETCH_RELEASE_STATUS_DETAILS_API_PATH: `${COMMON_API_PATH}/lookup/release-status`,

  /********************************** SEARCH API PATH *******************************************/
  WERS_CONCERN_SEARCH_API_PATH: `${COMMON_API_PATH}/search/wers-concern`,
  WERS_NOTICE_SEARCH_API_PATH: `${COMMON_API_PATH}/search/wers-notice`,

  /********************************** MODULE RELEASE API PATH *******************************************/
  ADD_REPLACE_SBL_API_PATH: `${COMMON_API_PATH}/module-release/sbl`,
  FIND_PARTS_BY_FIRMWARE_API_PATH: `${COMMON_API_PATH}/lookup/findPartsByFirmware`,
  ADD_REPLACE_PBL_API_PATH: `${COMMON_API_PATH}/module-release/pbl`,
  ADD_PARTII_PDX_API_PATH: `${COMMON_API_PATH}/module-release/part2-pdx`,
  ADD_NEW_MICRO_TYPE_API_PATH: `${COMMON_API_PATH}/module-release/main-micro-type`,
  /********************************** Export API PATH *******************************************/
  EXPORT_EXCEL_PARTS_API_PATH: `${COMMON_API_PATH}/export/parts`,
  EXPORT_XML_PARTS_API_PATH: `${COMMON_API_PATH}/export/firmware-xml`,
});

export default API_PATH;
