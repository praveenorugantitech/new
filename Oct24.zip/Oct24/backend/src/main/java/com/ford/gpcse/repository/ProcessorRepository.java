package com.ford.gpcse.repository;

import com.ford.gpcse.entity.Processor;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ProcessorRepository extends JpaRepository<Processor, String> {
    @Query("SELECT CONCAT(p.procN, '_', p.flashSizeNumX) FROM Processor p WHERE p.actvF = 'Y' ORDER BY p.sortOrdR")
    List<String> fetchActiveMicroNames();
}
