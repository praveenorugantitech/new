export class FindPartNumberModel {
    release_type : string = "find_partNumber";
    module_type : string = "";
    current_pbl : string = "";
    release_usage : string = "All";
    assembly_pn:string="";
    hardware_pn:string="";
    software_pn:string="";
    application_engineer:string="";
    catch_word:string="";
    calibration_number:string="";
    sw_main_strategy:string="";
    concern_number: string="";

}