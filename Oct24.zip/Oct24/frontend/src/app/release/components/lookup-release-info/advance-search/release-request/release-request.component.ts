import { Component } from '@angular/core';

@Component({
  selector: 'app-release-request',
  templateUrl: './release-request.component.html',
  styleUrl: './release-request.component.scss'
})
export class ReleaseRequestComponent {

}
