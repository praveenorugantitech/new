package com.ford.gpcse.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ReleaseStatusConcernDto {
    private String partR;
    private String partNumX;
    private String calibR;
    private String stratRelC;
    private String engineerCdsidC;
    private String hardwarePartR;
    private String microTypX;
    private String chipD;
    private String stratCalibPartR;
    private String statC;
    private String suplC;
    private String coreHardwarePartR;
    private String relTypC;
    private String relUsgC;

}
