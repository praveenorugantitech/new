package com.ford.gpcse.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.net.InetSocketAddress;
import java.net.Proxy;

@Configuration
public class RestTemplateProxyConfig {

    @Bean
    public RestTemplate restTemplateWithProxy() {
        // Configure the proxy with host and port
        Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress("internet.ford.com", 83));

        // Set up SimpleClientHttpRequestFactory with the proxy
        SimpleClientHttpRequestFactory factory = new SimpleClientHttpRequestFactory();
        factory.setProxy(proxy);

        // Create RestTemplate with the proxy-enabled factory
        return new RestTemplate(factory);
    }
}
