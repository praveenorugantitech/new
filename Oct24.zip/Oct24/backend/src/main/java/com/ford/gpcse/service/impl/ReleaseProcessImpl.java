package com.ford.gpcse.service.impl;

import com.ford.gpcse.entity.Part;
import com.ford.gpcse.entity.PartSignoff;
import com.ford.gpcse.entity.PartSignoffId;
import com.ford.gpcse.entity.Signoff;
import com.ford.gpcse.repository.PartRepository;
import com.ford.gpcse.repository.PartSignoffRepository;
import com.ford.gpcse.service.ReleaseProcessService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Service
@RequiredArgsConstructor
public class ReleaseProcessImpl implements ReleaseProcessService {

    private final PartSignoffRepository partSignOffRepository;
    private final PartRepository partRepository;

    @Override
    @Transactional
    public void setupSignOffProcess(String partNumber, String releaseType, String releaseUsage, String createUser, String lastUpdateUser) {

        List<String> signoffs = new ArrayList<>();

        // Calibration Process
        // DCUUL is used for all supplier calibration file uploads.
        processCalibration(releaseType, releaseUsage, signoffs);

        // Hard Lock Process
        // VBF Upload
        // See Calibration Process for VBFUL signOffs
        // Software Build signOffs
        processHardLock(releaseType, releaseUsage, signoffs);

        // Service Action
        if (!isHardwareReleaseType(releaseType) && !releaseType.equals("SBL")) {
            if (releaseUsage.equals("IPF") || releaseUsage.equals("SF") || releaseUsage.equals("PROD")) {
                signoffs.add("ISVAC");
            }
        }

        // EOL Process
        if (releaseType.equals("SBL")) {
            // Do nothing
        } else {
            if (releaseUsage.equals("IPF")) {
                signoffs.add("EOLVO");
            }
        }

        // Review Process
        reviewProcess(releaseType, releaseUsage, signoffs);

        if (!signoffs.isEmpty()) {
            addSignOffProcess(partNumber, signoffs, createUser, lastUpdateUser);
        }


    }

    private void addSignOffProcess(String partNumber, List<String> signoffs, String createUser, String lastUpdateUser) {
        signoffs.forEach(signoff -> {
            insertPartsignOffs(partNumber, createUser, lastUpdateUser, signoff);
            // TODO: if insert error  Response.Write("/ref/v2/asp_include/release_process.asp AddSignoffProcess(2)<br>Error Number:" & err.number & "<br>Error Description:" & err.Description)
            if (signoff.equals("PEERR") || signoff.equals("HWPER") || signoff.equals("CALUP")) {
                updatePartsignOffs(partNumber, signoff);
                // TODO: if update error "/ref/v2/asp_include/release_process.asp AddSignoffProcess(3)<br>Error Number:" & err.number & "<br>Error Description:" & err.Description
            }

        });

    }

    private void updatePartsignOffs(String partNumber, String signOffType) {
        // Update
        PartSignoff partsignOffsByPartR = partSignOffRepository.findByPartRAndSignOffTypC(partNumber, signOffType);
        partsignOffsByPartR.setUserCdsidC(partRepository.fetchCalibrationCodeByPartR(partNumber));
        partSignOffRepository.save(partsignOffsByPartR);
    }

    private void insertPartsignOffs(String partNumber, String createUser, String lastUpdateUser, String signOffType) {
        // Insert
        PartSignoff partsignOffs = PartSignoff.builder()
                .id(PartSignoffId.builder().signoffTypC(signOffType).partR(partNumber).build())
                .signoff(Signoff.builder().signoffTypC(signOffType).build())
                .part(Part.builder().partR(partNumber).build())
                .userCdsidC("")
                .deviatF("N")
                .createUserC(createUser)
                .lastUpdtUserC(lastUpdateUser)
                .build();

        partSignOffRepository.save(partsignOffs);
    }

    private void reviewProcess(String releaseType, String releaseUsage, List<String> signoffs) {
        switch (releaseType) {
            case "AREUL", "ARNAL", "AFG", "AFGO", "AFD", "AFDCX", "DCUA", "GDMA", "DLCMA", "DLCMS", "GSMA", "TRCMA",
                 "VCMA", "PMSEA", "NXTPA", "NXFGA", "NXMBA", "UCLSA", "TCCMA", "TCCMS", "GPCMA", "AWDHA", "HASM",
                 "AWDHS", "HASMS", "UTCU2" -> {
                switch (releaseUsage) {
                    case "CERT", "PREL" -> { /* No Review Process */ }
                    case "RC", "PROT" -> signoffs.add("PEERR");
                    default -> signoffs.addAll(Arrays.asList("PEERR", "SUPPR", "PEERW"));
                }
            }
            case "PSUPR", "BECMA", "BCCMA", "BCMBA", "BCMIA" -> {
                switch (releaseUsage) {
                    case "CERT", "PREL" -> { /* No Review Process */ }
                    case "RC", "PROT" -> signoffs.add("PEERR");
                    default -> signoffs.addAll(Arrays.asList("PEERR", "PEERW"));
                }
            }
            case "HARDW", "HWPT", "VCMH", "VCMHP", "HWUTC" -> signoffs.addAll(Arrays.asList("HWPER", "SUPPR"));
            case "DPS6" -> {
                switch (releaseUsage) {
                    case "CERT", "PREL" -> { /* No Review Process */ }
                    case "RC", "PROT" -> signoffs.add("PEERR");
                    case "SF" -> signoffs.addAll(Arrays.asList("PEERR", "PEERW"));
                    default -> signoffs.addAll(Arrays.asList("PEERR", "SUPPR", "PEERW"));
                }
            }
            case "TSUPS" -> {
                switch (releaseUsage) {
                    case "CERT", "PREL" -> { /* No Review Process */ }
                    case "RC", "PROT" -> signoffs.addAll(Arrays.asList("PEERR", "SUPPR"));
                    default -> signoffs.addAll(Arrays.asList("PEERR", "SUPPR", "PEERW"));
                }
            }
            default -> { /* No action for unhandled release types */ }
        }
    }


    private void processCalibration(String releaseType, String releaseUsage, List<String> signoffs) {
        switch (releaseType) {
            case "AFD" -> {
                switch (releaseUsage) {
                    case "CERT", "PREL" -> {
                        // No Calibration Process
                    }
                    default -> signoffs.addAll(Arrays.asList("CALUP", "CLSUP", "CLOBD", "SUDEP", "CLDEP", "VBFUL"));
                }
            }
            case "AREUL" -> {
                switch (releaseUsage) {
                    case "CERT", "PREL" -> {
                        // No Calibration Process
                    }
                    default -> signoffs.addAll(Arrays.asList("CALUP", "CLSUP", "CLOBD", "VBFUL"));
                }
            }
            case "PMSEA", "NXTPA", "NXFGA", "NXMBA", "UCLSA", "TCCMA", "TCCMS", "GPCMA", "DCUA",
                 "BECMA", "BCCMA", "BCMBA", "BCMIA", "PSUPR", "SBL", "TSUPS", "DLCMS", "AWDHS", "HASMS" -> {
                switch (releaseUsage) {
                    case "CERT", "PREL" -> {
                        // No Calibration Process
                    }
                    default -> signoffs.add("DCUUL"); // Supplier Calibration Upload
                }
            }
            default -> {
                // No Calibration Process for other types
            }
        }
    }

    public void processHardLock(String releaseType, String releaseUsage, List<String> signoffs) {
        // VBF Upload: See Calibration Process for VBFUL signOffs

        // Software Build signOffs
        switch (releaseUsage) {
            case "CERT", "PREL" -> {
                // No Software Build
            }
            case "RC", "PROT" -> {
                if (isHardwareReleaseType(releaseType)) {
                    // No PRISM build
                } else {
                    switch (releaseType) {
                        case "PMSEA", "NXTPA", "NXFGA", "NXMBA", "UCLSA", "TCCMA", "TCCMS", "GPCMA",
                             "DCUA", "BECMA", "BCCMA", "BCMBA", "BCMIA", "PSUPR", "SBL", "TSUPS",
                             "DLCMS", "AWDHS", "HASMS" ->
                                signoffs.addAll(Arrays.asList("PRDWL", "PRBLD")); // Supplier provided files
                        default -> signoffs.addAll(Arrays.asList("SWBLD", "PRBLD")); // PRISM Built file
                    }
                }
            }
            default -> {
                switch (releaseType) {
                    case "AFD", "PSUPR", "TSUPS", "AREUL", "PMSEA", "NXTPA", "NXFGA", "NXMBA",
                         "UCLSA", "TCCMA", "TCCMS", "GPCMA", "BECMA", "BCCMA", "BCMBA", "BCMIA" -> {
                        signoffs.addAll(Arrays.asList("SWWER", "PRDWL", "PRBLD"));
                    }
                    case "AFG", "AFGO", "ARNAL", "UTCU2", "DPS6", "GSMA", "HASM", "TRCMA",
                         "DLCMA", "AWDHA", "GDMA", "VCMA", "DLCMS", "AWDHS", "HASMS" -> {
                        signoffs.addAll(Arrays.asList("SWWER", "PRDWL", "PRBLD")); // Software WERS & FWDB Validation, PRISM Download, PRISM Build
                    }
                    case "DCUA", "AFDCX" -> signoffs.addAll(Arrays.asList("SSBLD", "SWWER", "PRDWL", "PRBLD"));
                    case "SBL" -> signoffs.addAll(Arrays.asList("PRDWL", "PRBLD"));
                    case "HARDW", "HWUTC", "BECMH", "BCCMH", "BCMBH", "BCMIH", "PMSEH",
                         "NXTPH", "NXFGH", "NXMBH", "UCLSH", "TCCMH", "GPCMH", "AWDHH",
                         "HPCMH", "DLCMH", "GSMH", "TRCMH", "DCUH", "GDMH", "VCMH" -> {
                        signoffs.add("SWWER"); // Software WERS & FWDB Validation
                    }
                }
            }
        }

        // Software Drawing
        if (releaseType.equals("SBL")) {
            // Do nothing
        } else {
            if (releaseUsage.equals("CERT") || releaseUsage.equals("IPF") ||
                    releaseUsage.equals("SF") || releaseUsage.equals("RC") ||
                    releaseUsage.equals("PROT")) {
                // No Software Drawing
            } else {
                signoffs.add("SWDRW");
            }
        }

        // Telegram
        if (releaseUsage.equals("CERT")) {
            // No Telegram
        } else {
            signoffs.add("TELGR");
        }

        // IVS Assembly signOffs
        if (releaseType.equals("SBL")) {
            switch (releaseUsage) {
                case "CERT", "PREL" -> {
                    // No IVS
                }
                case "RC", "PROT", "PROD" -> {
                    signoffs.add("IVSSB"); // Pre Telegram
                }
                default -> {
                    // No action for other cases
                }
            }
        } else if (!isHardwareReleaseType(releaseType)) {
            switch (releaseUsage) {
                case "CERT", "PREL" -> {
                    // No IVS
                }
                case "RC", "PROT" -> {
                    signoffs.addAll(Arrays.asList("SRPUL", "IVSSB")); // Pre Telegram
                }
                case "IPF", "SF", "PROD", "SERV", "IPFIN" -> {
                    signoffs.addAll(Arrays.asList("SRPUL", "IVSSB", "IVSAB", "IVSEM", "IVSXM")); // Pre Telegram
                }
                default -> {
                    // No action for other cases
                }
            }
        }


    }

    private boolean isHardwareReleaseType(String releaseType) {
        switch (releaseType) {
            case "BCCMH", "BCMBH", "BCMIH", "BECMH", "HWPT", "HWUTC", "HWPUT", "HWCUT",
                 "HARDW", "HRDCN", "PMSEH", "NXTPH", "NXFGH", "NXMBH", "UCLSH", "GPCMH",
                 "AWDHH", "HPCMH", "TCCMH", "DCUH", "GDMH", "DLCMH", "GSMH", "TRCMH",
                 "VCMH", "VCMHP", "VCMHC" -> {
                return true; // It's a hardware release type
            }
            default -> {
                return false; // It's not a hardware release type
            }
        }
    }
}
