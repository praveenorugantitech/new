package com.ford.gpcse.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ReleaseStatusDto {
    private String concernC;
    private String partR;
    private String statC;
    private String moduleTypX;
    private String relTypX;
    private LocalDate concernY;
}
