import { Component } from '@angular/core';

@Component({
  selector: 'app-prism-input',
  templateUrl: './prism-input.component.html',
  styleUrl: './prism-input.component.scss'
})
export class PrismInputComponent {

}
