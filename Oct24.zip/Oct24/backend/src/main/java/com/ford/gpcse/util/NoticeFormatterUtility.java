package com.ford.gpcse.util;

public class NoticeFormatterUtility {
    // Private constructor to prevent instantiation
    private NoticeFormatterUtility() {
        throw new UnsupportedOperationException("Utility class cannot be instantiated");
    }

    public static String formatWersNotice(String wersNotice) {
        if (wersNotice == null || wersNotice.trim().length() < 16) {
            return null;
        }
        wersNotice = wersNotice.replace(" ", "").replace("-", "").trim();
        return wersNotice.length() >= 16 ? wersNotice.substring(0, 16) + "%" : null;
    }

}
