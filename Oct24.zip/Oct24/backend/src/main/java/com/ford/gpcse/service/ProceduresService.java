package com.ford.gpcse.service;

import com.ford.gpcse.bo.EditPartRequest;

public interface ProceduresService {
    void editPart(EditPartRequest editPartRequest);
}
