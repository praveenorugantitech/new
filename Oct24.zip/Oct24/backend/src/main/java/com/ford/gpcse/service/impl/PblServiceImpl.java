package com.ford.gpcse.service.impl;

import com.ford.gpcse.bo.CreatePblRequest;
import com.ford.gpcse.bo.ReplacePblRequest;
import com.ford.gpcse.dto.HardwareEmailPartDto;
import com.ford.gpcse.entity.Firmware;
import com.ford.gpcse.entity.FirmwareItem;
import com.ford.gpcse.exception.FirmwareAlreadyRequestedException;
import com.ford.gpcse.exception.UnableToInsertException;
import com.ford.gpcse.external.email.service.EmailService;
import com.ford.gpcse.model.Email;
import com.ford.gpcse.repository.FirmwareItemRepository;
import com.ford.gpcse.repository.FirmwareRepository;
import com.ford.gpcse.repository.PartRepository;
import com.ford.gpcse.service.PblService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class PblServiceImpl implements PblService {

    private final FirmwareItemRepository firmwareItemRepository;
    private final PartRepository partRepository;
    private final EmailService emailService;
    private final FirmwareRepository firmwareRepository;

    @Override
    @Transactional
    public void createPbl(CreatePblRequest createPblRequest) {
        // Check if the firmware item already exists
        Long count = firmwareItemRepository.countByFirmwareItmX(createPblRequest.getNewPbl());

        if (count > 0) {
            throw new FirmwareAlreadyRequestedException(createPblRequest.getNewPbl());
        }

        // Get the firmwareK based on the module type code
        List<Firmware> firmwareList = firmwareRepository.fetchFirmwareByModuleTypeCode(createPblRequest.getModuleTypeCode(), "PBL");
        if (firmwareList.isEmpty()) {
            throw new UnableToInsertException("No firmware found for module type: " + createPblRequest.getModuleTypeCode());
        }

        // Select the top firmwareK
        Long firmwareK = firmwareList.get(0).getFirmwareK();

        // Create the FirmwareItem entity
        FirmwareItem firmwareItem = FirmwareItem.builder()
                .firmwareItmX(createPblRequest.getNewPbl())
                .firmwareK(firmwareK)
                .sortOrdR(0L)
                .createUserC(createPblRequest.getCreateUser())
                .lastUpdtUserC(createPblRequest.getLastUpdateUser())
                .build();

        // Save the FirmwareItem entity
        try {
            firmwareItemRepository.save(firmwareItem);
        } catch (Exception e) {
            throw new UnableToInsertException("Unable to insert " + createPblRequest.getNewPbl() + " firmware found for " + createPblRequest.getModuleTypeCode() + " module type.");
        }

        log.info("Part {} has been added to the firmware drop down list", createPblRequest.getNewPbl());
    }


    @Override
    @Transactional
    public void replacePbl(ReplacePblRequest replacePblRequest) {

        // Check if the firmware item already exists
        Long count = firmwareItemRepository.countByFirmwareItmX(replacePblRequest.getNewPbl());

        if (count > 0) {
            throw new FirmwareAlreadyRequestedException(replacePblRequest.getNewPbl());
        }

        // Get the firmwareK based on the module type code
        List<Firmware> firmwareList = firmwareRepository.fetchFirmwareByModuleTypeCode(replacePblRequest.getModuleTypeCode(), "PBL");
        if (firmwareList.isEmpty()) {
            throw new UnableToInsertException("No firmware found for module type: " + replacePblRequest.getModuleTypeCode());
        }

        // Select the top firmwareK
        Long firmwareK = firmwareList.get(0).getFirmwareK();

        // Create the FirmwareItem entity
        FirmwareItem firmwareItem = FirmwareItem.builder()
                .firmwareItmX(replacePblRequest.getNewPbl())
                .firmwareK(firmwareK)
                .sortOrdR(0L)
                .createUserC(replacePblRequest.getCreateUser())
                .lastUpdtUserC(replacePblRequest.getLastUpdateUser())
                .build();

        // Save the FirmwareItem entity
        try {
            firmwareItemRepository.save(firmwareItem);
        } catch (Exception e) {
            throw new UnableToInsertException("Unable to insert " + replacePblRequest.getNewPbl() + " firmware found for " + replacePblRequest.getModuleTypeCode() + " module type.");
        }

        if (replacePblRequest.getPartNumbers().isEmpty()) {
            sendHardwareEmail(replacePblRequest.getPartNumbers());
        }

        log.info("Part {} has been added to the firmware drop down list", replacePblRequest.getNewPbl());
    }


    private void sendHardwareEmail(List<String> partNumbers) {
        if (partNumbers == null || partNumbers.isEmpty()) {
            return;
        }

        // Query the database using the JPA repository
        List<HardwareEmailPartDto> results = partRepository.fetchPartsForEmail(partNumbers);

        if (results.isEmpty()) {
            return;
        }

        // Prepare email content
        String subject = "Revise hardware release. Replace PBL";
        StringBuilder emailBody = new StringBuilder();
        emailBody.append("<html><body><div>Please revise the following parts.</div><table border='1'>")
                .append("<tr><th>Assembly PN</th><th>Hardware PN</th><th>Core Hardware PN</th><th>Micro Type</th><th>D&R Eng</th></tr>");

        List<String> engineers = new ArrayList<>();

        for (HardwareEmailPartDto part : results) {
            String engineer = part.getEngineerCdsidC();
            if (!engineers.contains(engineer)) {
                engineers.add(engineer);
            }

            emailBody.append("<tr>")
                    .append("<td>").append(part.getPartR()).append("</td>")
                    .append("<td>").append(part.getHardwarePartR()).append("</td>")
                    .append("<td>").append(part.getCoreHardwarePartR()).append("</td>")
                    .append("<td>").append(part.getMicroTypX()).append("</td>")
                    .append("<td>").append(engineer).append("</td>")
                    .append("</tr>");
        }

        emailBody.append("</table></body></html>");

        // Send email
        emailService.sendMail(Email.builder().subject(subject).to(engineers).from("pcserel@ford.com").body(emailBody.toString()).build());
    }


}
