package com.ford.gpcse.bo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
@SuperBuilder
public class ReplacePblRequest {
    private String newPbl;
    private String moduleTypeCode;
    private String createUser;
    private String lastUpdateUser;
    private List<String> partNumbers;
}
