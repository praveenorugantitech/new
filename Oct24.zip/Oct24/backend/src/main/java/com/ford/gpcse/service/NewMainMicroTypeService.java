package com.ford.gpcse.service;

import com.ford.gpcse.bo.NewMicroMicroTypeRequest;

public interface NewMainMicroTypeService {

    void addNewMainMicroType(NewMicroMicroTypeRequest newMicroMicroTypeRequest);

}
