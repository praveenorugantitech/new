import { Component, OnInit } from "@angular/core";
import {
  AddRequestMainMicroTypeModel,
  AddPostRequestMainMicroTypeModel,
} from "../../../utils/models/request-main-micro-type";
import { ReleaseService } from "../../../utils/services/release.service";
import Swal from "sweetalert2";
import { Router } from "@angular/router";
import { ErrorResponse } from "../../../utils/models/error-response.model";
import { ReleaseUtils } from "../../../utils/ReleaseUtils";

import {
  ModuleTypesOptionsModel,
  SupplierOptionsModel,
  ModuleNamesOptionsModel,
  MicroNamesOptionsModel,
} from "../../../utils/models/shared.model";
@Component({
  selector: "app-request-new-main-micro-type",
  templateUrl: "./request-new-main-micro-type.component.html",
  styleUrl: "./request-new-main-micro-type.component.scss",
})
export class RequestNewMainMicroTypeComponent implements OnInit {
  constructor(private router: Router, private releaseService: ReleaseService) {}

  isPCMVisible: boolean = false;
  internalFlashMemoryVisible: boolean = false;
  externalFlashMemoryVisible: boolean = false;
  moduleFamilyVisible: boolean = false;
  microNonPCMNameVisible: boolean = false;

  internalMemorySizeValue: string = "";
  selectedInternalUnit: string = "";
  internalFlashMemorySize: string = "";

  externalMemorySizeValue: string = "";
  selectedExternalUnit: string = "";
  externalFlashMemorySize: string = "";

  addRequestMainMicroTypeData: AddRequestMainMicroTypeModel =
    new AddRequestMainMicroTypeModel();
  supplierOptions: Array<SupplierOptionsModel> = new Array();
  moduleTypeOptions: Array<ModuleTypesOptionsModel> = new Array();
  moduleNameOptions: Array<ModuleNamesOptionsModel> = new Array();
  microNameOptions: Array<MicroNamesOptionsModel> = new Array();

  filteredOptionsSupplier: Array<SupplierOptionsModel> = new Array();
  filteredOptionsModuleType: Array<ModuleTypesOptionsModel> = new Array();
  filteredOptionsModuleNameType: Array<ModuleNamesOptionsModel> = new Array();
  filteredOptionsMicroNameType: Array<MicroNamesOptionsModel> = new Array();

  ngOnInit() {
    this.initializeAndSetupData();
  }

  initializeAndSetupData() {
    this.getSupplierData();
    this.getModuleTypes();
    this.getModuleNames();
    this.getMicroNames();
  }

  updateExternalFlashMemorySize() {
    this.externalFlashMemorySize = `${this.externalMemorySizeValue} ${this.selectedExternalUnit}`;
    this.buildNewMainMicroTypeName();
  }

  updateInternalFlashMemorySize() {
    this.internalFlashMemorySize = `${this.internalMemorySizeValue} ${this.selectedInternalUnit}`;
    this.buildNewMainMicroTypeName();
  }

  getSupplierData() {
    try {
      this.releaseService.getSupplier().subscribe((res) => {
        if (res.length > 0) {
          this.supplierOptions = res;
          this.filterOptions("supplier");
        } else {
          console.error(
            "Something went wrong while fetching the suppliers types."
          );
        }
      });
    } catch (err) {
      console.error(err);
    }
  }

  getModuleTypes() {
    try {
      this.releaseService.getModuleTypes().subscribe((res) => {
        if (res.length > 0) {
          this.moduleTypeOptions = res;
          this.filterOptions("module_type");
        } else {
          console.error(
            "Something went wrong while fetching the module types."
          );
        }
      });
    } catch (err) {
      console.error(err);
    }
  }

  getModuleNames() {
    this.releaseService.getModuleNames().subscribe(
      (res: string[]) => {       
        if (res.length > 0) {         
          this.moduleNameOptions = res.map(name => ({ moduleName: name }));
          this.filterOptions("module_name");
        } else {
          console.error(
            "Something went wrong while fetching the module names."
          );
        }
      },
      (error) => {
        console.error(error);
      }
    );
  }

  getMicroNames() {
    this.releaseService.getMicroNames().subscribe(
      (res: string[]) => {       
        if (res.length > 0) {
          // Convert string array to objects if needed
          this.microNameOptions = res.map(name => ({ microName: name }));
          this.filterOptions("micro_name");
        } else {
          console.error(
            "Something went wrong while fetching the micro names."
          );
        }
      },
      (error) => {
        console.error(error);
      }
    );
  }
  
  

  filterOptions(changeOpt: String) {
    if (changeOpt === "supplier") {
      if (this.addRequestMainMicroTypeData.supplierName) {
        this.filteredOptionsSupplier = this.supplierOptions.filter((option) =>
          option.supplierName
            ?.toLowerCase()
            .includes(
              String(
                this.addRequestMainMicroTypeData.supplierName.toLowerCase()
              )
            )
        );
      } else {
        this.filteredOptionsSupplier = this.supplierOptions;
      }
    }
    if (changeOpt === "module_type") {
      if (this.addRequestMainMicroTypeData.moduleTypeName) {
        this.filteredOptionsModuleType = this.moduleTypeOptions.filter(
          (option) =>
            option.moduleTypeName
              .toLowerCase()
              .includes(
                String(
                  this.addRequestMainMicroTypeData.moduleTypeName.toLowerCase()
                )
              )
        );
      } else {
        this.filteredOptionsModuleType = this.moduleTypeOptions;
      }
    }

    if (changeOpt === "module_name") {
      if (this.addRequestMainMicroTypeData.moduleName) {
        this.filteredOptionsModuleNameType = this.moduleNameOptions.filter(
          (option) =>
            option.moduleName
              .toLowerCase()
              .includes(
                String(
                  this.addRequestMainMicroTypeData.moduleName.toLowerCase()
                )
              )
        );
      } else {
        this.filteredOptionsModuleNameType = this.moduleNameOptions;
      }
    }

    if (changeOpt === "micro_name") {
      if (this.addRequestMainMicroTypeData.microName) {
        this.filteredOptionsMicroNameType = this.microNameOptions.filter(
          (option) =>
            option.microName
              .toLowerCase()
              .includes(
                String(this.addRequestMainMicroTypeData.microName.toLowerCase())
              )
        );
      } else {
        this.filteredOptionsMicroNameType = this.microNameOptions;
      }
    }   
  }

  handleModuleType(moduleTypeName: string) {
    this.isPCMVisible = moduleTypeName === "PCM" || moduleTypeName === "VCM";
    this.internalFlashMemoryVisible = !this.isPCMVisible && !!moduleTypeName;
    this.externalFlashMemoryVisible = !this.isPCMVisible && !!moduleTypeName;
    this.moduleFamilyVisible = !this.isPCMVisible && !!moduleTypeName;
    this.microNonPCMNameVisible = !this.isPCMVisible && !!moduleTypeName;
    this.buildNewMainMicroTypeName();
  }

  validateMainMicroTypeData() {
    const {
      supplierName,
      moduleTypeName,
      moduleName,
      microName,
      moduleFamily,
      microNonPCMName,
    } = this.addRequestMainMicroTypeData;

    let errorMessages = [];

    // Check required fields
    if (!supplierName) {
      errorMessages.push("* Select Supplier.");
    }
    if (!moduleTypeName || moduleTypeName === "-NA-") {
      errorMessages.push("* Select Module Type.");
    } else if (moduleTypeName === "PCM" || moduleTypeName === "VCM") {
      if (!moduleName || moduleName === "-NA-") {
        errorMessages.push("* Select Module Name.");
      }
      if (!microName || microName === "-NA-") {
        errorMessages.push("* Select Micro Name.");
      }
    } else {
      if (!moduleFamily) {
        errorMessages.push("* Module Family Required.");
      }
      if (!microNonPCMName) {
        errorMessages.push("* Micro Name Required.");
      }
      if (!this.internalMemorySizeValue) {
        errorMessages.push("* Internal Flash Size Required.");
      }

      if (this.internalMemorySizeValue && !this.selectedInternalUnit) {
        errorMessages.push("* Select Internal Flash Size MB or KB.");
      }

      if (this.externalMemorySizeValue && !this.selectedExternalUnit) {
        errorMessages.push("* Select External Flash Size MB or KB.");
      }
    }

    // If there are any error messages, display them
    if (errorMessages.length > 0) {
      const fullMessage =
        errorMessages.join("<br>") +
        "<br><br>Please correct the issues listed above and try again.";
      Swal.fire({
        title: "Error",
        html: fullMessage,
        icon: "error",
      });
      return false;
    }

    return true;
  }

  addNewMainMicroType() {
    if (this.validateMainMicroTypeData()) {
      const { moduleTypeCode, mainMicroTypeName, supplierCode, supplierName } =
        this.addRequestMainMicroTypeData;

      const dataToSend: AddPostRequestMainMicroTypeModel = {
        mainMicroTypeName,
        createUser: "DSADASH1",
        lastUpdateUser: "DSADASH1",
        moduleTypeCode,
        supplierCode,
        supplierName,
      };

      this.releaseService.addNewMainMicroType(dataToSend).subscribe({
        next: (response: any) => {
          const successMessage = response;
          Swal.fire({
            icon: "success",
            title: "Success",
            text: successMessage,
            confirmButtonColor: "#00467f",
          }).then(() => {
            this.router.navigate(["/"]);
          });
        },
        error: (error: any) => {
          // Parse the error string
          let errorResponse: ErrorResponse;
          try {
            errorResponse = JSON.parse(error.error);
          } catch (e) {
            errorResponse = {
              status: "error",
              message: "An unexpected error occurred.",
            };
          }

          const errorMessage =
            errorResponse.message || "An unexpected error occurred.";
          ReleaseUtils.showErrorSweetAlert("Error", `${errorMessage}`);
        },
      });
    }
  }

  cancelSubmit() {
    this.addRequestMainMicroTypeData = new AddRequestMainMicroTypeModel();
    window.scrollTo({ top: 0, behavior: "smooth" });
    this.router.navigate(["/"]);
  }

  buildNewMainMicroTypeName() {
  
    let sName = "";

    // Get supplier name (first letter)
    sName += this.addRequestMainMicroTypeData.supplierName.charAt(0) + "_";

    // Determine if module type is PCM or VCM
    if (
      this.addRequestMainMicroTypeData.moduleTypeName === "PCM" ||
      this.addRequestMainMicroTypeData.moduleTypeName === "VCM"
    ) {
      sName += this.addRequestMainMicroTypeData.moduleName + "_";
      sName += this.addRequestMainMicroTypeData.microName + "_IB";
    } else {
      // Check if necessary fields are selected
      if (
        !this.addRequestMainMicroTypeData.moduleTypeName ||
        this.internalFlashMemorySize === ""
      ) {
        this.addRequestMainMicroTypeData.mainMicroTypeName = "";
        return;
      }

      sName += this.addRequestMainMicroTypeData.moduleFamily + "_";
      sName += this.addRequestMainMicroTypeData.microNonPCMName + "_";
      sName += this.internalFlashMemorySize + "I";

      if (
        this.externalMemorySizeValue !== "" &&
        this.selectedExternalUnit !== "-NA-"
      ) {
        sName +=
          "_" + this.externalMemorySizeValue + this.selectedExternalUnit + "E";
      }
      sName += "_IB";
    }

    this.addRequestMainMicroTypeData.mainMicroTypeName = sName.toUpperCase();
  }
}
