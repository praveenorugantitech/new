package com.ford.gpcse.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Data
@SuperBuilder
@Table(name = "WPCMF16_PROC")
public class Processor {

    @Id
    @Column(name = "PCMF16_PROC_D")
    private String procD;

    @Column(name = "PCMF16_PROC_N")
    private String procN;

    @Column(name = "PCMF16_SPD_NUM_X")
    private String spdNumX;

    @Column(name = "PCMF16_FLASH_SIZE_NUM_X")
    private String flashSizeNumX;

    @Column(name = "PCMF16_SORT_ORD_R")
    private Long sortOrdR;

    @Column(name = "PCMF16_ACTV_F")
    private String actvF;

    @Column(name = "PCMR16_CREATE_USER_C", nullable = false)
    private String createUserC;

    @Column(name = "PCMR16_CREATE_S", nullable = false, updatable = false)
    @CreationTimestamp
    private LocalDateTime createS;

    @Column(name = "PCMR16_LAST_UPDT_USER_C", nullable = false)
    private String lastUpdtUserC;

    @Column(name = "PCMR16_LAST_UPDT_S", nullable = false)
    @UpdateTimestamp
    private LocalDateTime lastUpdtS;


}
