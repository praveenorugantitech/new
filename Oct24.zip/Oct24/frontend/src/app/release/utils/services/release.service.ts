import { Injectable } from "@angular/core";
import { HttpClient, HttpParams } from "@angular/common/http";
import { Observable, of } from "rxjs";
import { AddSblPostModel, ReplaceSblPutModel } from "../models/sbl.model";
import { AddPartIIPdxPostModel } from "../models/part-II.model";
import { AddPostRequestMainMicroTypeModel } from "../models/request-main-micro-type";
import { exportToExcelPostModel } from "../models/export-excel.model";
import API_PATH from "./releaseApiPath";
import {
  AddPblData,
  FetchPartDetails,
  ReplacePblPutModel,
} from "../models/pbl.model";

@Injectable({
  providedIn: "root",
})
export class ReleaseService {
  constructor(private http: HttpClient) {}

  /********************************** LOOKUP API CALLS *********************************************/

  getSupplier(): Observable<any> {
    return this.http.get(API_PATH.SUPPLIER_API_PATH);
  }

  getMicroTypes(moduleType: String): Observable<any> {
    return this.http.get(
      `${API_PATH.MICROTYPES_API_PATH}?moduleTypeCode=${moduleType}`
    );
  }

  getModuleTypes(): Observable<any> {
    return this.http.get(API_PATH.MODULETYPES_API_PATH);
  }

  getModuleNames(): Observable<string[]> {
    return this.http.get<string[]>(API_PATH.MODULENAMES_API_PATH);
  }

  getMicroNames(): Observable<string[]> {
    return this.http.get<string[]>(API_PATH.MICRONAMES_API_PATH);
  }

  getReleaseStatusDetails(): Observable<any> {
    return this.http.get(
      API_PATH.FETCH_RELEASE_STATUS_DETAILS_API_PATH,     
      { responseType: "json" }
    );
  }

  /********************************** SEARCH API CALLS ***************************************************/

  getFirmwareDetailsByWersConcern(wersConcern: string): Observable<any[]> {
    return this.http.get<any[]>(
      `${API_PATH.WERS_CONCERN_SEARCH_API_PATH}/${wersConcern}`
    );
  }

  getFirmwareDetailsByWersNotice(wersNotice: string): Observable<any[]> {
    return this.http.get<any[]>(
      `${API_PATH.WERS_NOTICE_SEARCH_API_PATH}/${wersNotice}`
    );
  }

  /********************************** MODULE RELEASE API CALLS *******************************************/
  addSbl(newSblData: AddSblPostModel): Observable<any> {
    return this.http.post(
      API_PATH.ADD_REPLACE_SBL_API_PATH,
      { ...newSblData },
      { responseType: "text" }
    );
  }

  replaceSbl(replaceSblData: ReplaceSblPutModel): Observable<any> {
    return this.http.put(
      API_PATH.ADD_REPLACE_SBL_API_PATH,
      { ...replaceSblData },
      { responseType: "text" }
    );
  }

  addPBL(pblData: AddPblData): Observable<any> {
    return this.http.post(
      API_PATH.ADD_REPLACE_PBL_API_PATH,
      { ...pblData },
      { responseType: "text" }
    );
  }

  replacePBL(pblData: ReplacePblPutModel): Observable<any> {
    return this.http.put(
      API_PATH.ADD_REPLACE_PBL_API_PATH,
      { ...pblData },
      { responseType: "text" }
    );
  }

  getPartsByFirmware(fetchPartDetails: FetchPartDetails): Observable<any> {
    return this.http.post(
      API_PATH.FETCH_PARTS_BY_FIRMWARE_API_PATH,
      { ...fetchPartDetails },
      { responseType: "json" }
    );
  }

  addPartIIPDX(partIIPdxData: AddPartIIPdxPostModel): Observable<any> {
    return this.http.post(
      API_PATH.ADD_PARTII_PDX_API_PATH,
      { ...partIIPdxData },
      { responseType: "text" }
    );
  }

  addNewMainMicroType(
    addNewMainMicroTypeData: AddPostRequestMainMicroTypeModel
  ): Observable<any> {
    return this.http.post(
      API_PATH.ADD_NEW_MICRO_TYPE_API_PATH,
      { ...addNewMainMicroTypeData },
      { responseType: "text" }
    );
  }

  /********************************** EXPORT API CALLS *******************************************/

  exportPartsToExcel(partNumbers: string[]): Observable<any> {
    return this.http.post(API_PATH.EXPORT_EXCEL_PARTS_API_PATH, partNumbers, {
      responseType: "blob",
    });
  }

  exportPartsToXML(exportToExcelData: exportToExcelPostModel): Observable<any> {
    return this.http.post(
      API_PATH.EXPORT_XML_PARTS_API_PATH,
      { ...exportToExcelData },
      {
        responseType: "blob",
      }
    );
  }
}
