export class SupplierOptionsModel {
    supplierName: string = "";
    supplierCode: string = "";
}
export class ModuleTypesOptionsModel {
    moduleTypeName: string = "";
    moduleTypeCode: string = "";
}
export class MicroTypesOptionModel{
    microTypeCode: number = 0;
    microTypeName: string = "";
}


export class ModuleNamesOptionsModel {
    moduleName: string = "";  
}

export class MicroNamesOptionsModel {
    microName: string = "";  
}