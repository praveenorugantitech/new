package com.ford.gpcse.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Data
@SuperBuilder
@Table(name = "WPCMR13_FIRMWARE_ROLE")
public class FirmwareRole {

    @EmbeddedId
    private FirmwareRoleId firmwareRoleId;

    @ManyToOne
    @JoinColumn(name = "PCMR03_FIRMWARE_K", referencedColumnName = "PCMR03_FIRMWARE_K", insertable = false, updatable = false)
    private Firmware firmware;

    @ManyToOne
    @JoinColumn(name = "PCM002_ROLE_K", referencedColumnName = "PCM002_ROLE_K", insertable = false, updatable = false)
    private Role role;

    @Column(name = "PCMR13_CREATE_USER_C", nullable = false)
    private String createUserC;

    @Column(name = "PCMR13_CREATE_S", nullable = false, updatable = false)
    @CreationTimestamp
    private LocalDateTime createS;

    @Column(name = "PCMR13_LAST_UPDT_USER_C", nullable = false)
    private String lastUpdtUserC;

    @Column(name = "PCMR13_LAST_UPDT_S", nullable = false)
    @UpdateTimestamp
    private LocalDateTime lastUpdtS;
}
