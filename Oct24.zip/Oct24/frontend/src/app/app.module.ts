import { NgModule } from "@angular/core";
import { provideHttpClient } from "@angular/common/http";
import { ToastrModule } from "ngx-toastr";

@NgModule({
  declarations: [],
  imports: [
    ToastrModule.forRoot({
      timeOut: 3000,
      positionClass: "toast-top-right",
      preventDuplicates: true,
      progressBar: true,     
    }),
  ],
  providers: [provideHttpClient()],
  bootstrap: [],
})
export class AppModule {}
