package com.ford.gpcse.repository;

import com.ford.gpcse.entity.ProgramPart;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ProgramPartRepository extends JpaRepository<ProgramPart,Long> {

    List<ProgramPart> findByPart_PartRIn(List<String> partNumbers);
}
